############################################################################
# CONFIDENTIAL
#
# Copyright (c) 2020 Qualcomm Technologies International, Ltd.
#   %%version
#
############################################################################
"""Provides a class to represent a processor on the Apps subsystem for QCC710"""

import re
from csr.wheels import iprint
from csr.dev.hw.core.arm_core import CortexM0Core, ArmCortexMCoreInfo
from csr.dev.fw.meta.i_firmware_build_info import SimpleFirmwareBuildInfo,\
    SnapdragonLLVMArmToolchain
from csr.dev.fw.firmware import BasicFirmware, HasDbgCall
from csr.dev.hw.core.mixin.supports_custom_digits import SupportsMultifileCustomDigits
from csr.dev.hw.core.meta.io_struct_io_map_info import IoStructIOMapInfo
from csr.dev.fw.bt_firmware import BTDefaultZeagleFirmware
from .meta.io_struct_io_map_info import IoStructIOMapInfo


class QCC710AppsFirmware(BasicFirmware, HasDbgCall):
    
    def load(self, quiet=False):
        """
        Load the loadable sections found in the ELF file into NVM
        """
        for section in self.build_info.elf_code.sections:
            if not quiet:
                iprint("Loading section '{}'".format(section.name))
            self._core.subsystem.chip.nvm.write_data(section.paddr, section.data.tolist(),
                                                     quiet=quiet)

class QCC710AppsFirmwareBuildInfo(SimpleFirmwareBuildInfo):
    toolchain = SnapdragonLLVMArmToolchain


class QCC710AppsCoreInfo(ArmCortexMCoreInfo, SupportsMultifileCustomDigits):
    DIGITS_SS_NAME = "apps_sys"
    IO_STRUCT_NAME_PATTERNS = ("(chip|apss|apps)",)

    @property
    def io_map_info(self):

        try:
            self._io_map_info
        except AttributeError:
            self._io_map_info = IoStructIOMapInfo(self.custom_io_structs, None,
                                                  self.layout_info)
        return self._io_map_info


class QCC710AppsCore(CortexM0Core):
    """
    CortexM4Core for Slate.

    The key property of this class over CortexM4Core is that when
    finding the io_struct it can fall back to looking in the qcom_iostructs
    module in someone's Python installation.  This mechanism exists to allow
    register maps to be contained within N2K boundaries, rather than having to
    have them checked into Pydbg's source code, which is available very widely.
    """

    IO_STRUCT_MODULE_NAME = "qcc710_apss_io_struct" # this is a placeholder for now

    def __init__(self, subsystem, access_cache_type, io_struct):

        self._io_struct = io_struct
        CortexM0Core.__init__(self, access_cache_type)
        self.subsystem = subsystem

    @property
    def name(self):
        """Name used in UI for this subsystem"""
        return "apps"

    @property
    def nicknames(self):
        return ["apps"]

    @property
    def data(self):
        return self._data.port

    @property
    def _info(self):
        try:
            self._core_info
        except AttributeError:
            if self._io_struct is None:
                self._core_info = QCC710AppsCoreInfo(
                    custom_digits=None,
                    custom_digits_modules=[self.IO_STRUCT_MODULE_NAME])
            else:
                self._core_info = QCC710AppsCoreInfo(
                    custom_digits=self._io_struct,
                    custom_digits_modules=None)
        return self._core_info

    @property
    def default_firmware_type(self):
        return lambda x: None

    @property
    def firmware_type(self):
        return QCC710AppsFirmware

    @property
    def firmware_build_info_type(self):
        """returns class for build info"""
        return QCC710AppsFirmwareBuildInfo

    @property
    def core_commands(self):
        return {}, []


class QCC710BTCoreInfo(ArmCortexMCoreInfo, SupportsMultifileCustomDigits):
    """The CoreInfo for the QCC710BTCore"""

    IO_STRUCT_NAME_PATTERNS = ["bt", "(chip|apss)"]

    def __init__(self, custom_digits=None, custom_digits_modules=None):
        ArmCortexMCoreInfo.__init__(self)
        SupportsMultifileCustomDigits.__init__(
            self, custom_digits=custom_digits,
            custom_digits_modules=custom_digits_modules)

    @staticmethod
    def _get_canonical_module_name(filename):
        #Unfortunately the names might be a bit munged,
        # so we strip that out, and then we *should* have a string that
        # matches the canonical name of a module
        if filename.endswith(".py"):
            filename = filename[:-3]
        filename = re.sub(r"_emu_\d+p\d+_", "_", filename)
        return filename

    @property
    def io_map_info(self):

        try:
            self._io_map_info
        except AttributeError:
            self._io_map_info = IoStructIOMapInfo(self.custom_io_structs, None,
                                                  self.layout_info)
        return self._io_map_info

class QCC710BTCore(CortexM0Core):
    """
    BTZeagleCore for QCC710.  We may find that QCC710 doesn't fit nicely into the
    Zeagle world because it will be running a very cut-down version of the
    firmware.  However, we'll cross the bridge when we come to it.

    The key property of this class over GenericBTZeagleCore is that when
    finding the io_struct it can fall back to looking in the qcom_iostructs
    module in someone's Python installation.  This mechanism exists to allow
    register maps to be contained within N2K boundaries, rather than having to
    have them checked into Pydbg's source code, which is available very widely.
    """

    IO_STRUCT_MODULE_NAMES = ("qcc710_bt_io_struct", "qcc710_chip_io_struct")

    def __init__(self, subsystem, access_cache_type, io_struct):

        CortexM0Core.__init__(self, access_cache_type)

        self.subsystem = subsystem
        self._io_struct = io_struct

    @property
    def _info(self):
        try:
            self._core_info
        except AttributeError:
            if self._io_struct is None:
                self._core_info = QCC710BTCoreInfo(
                    custom_digits_modules=self.IO_STRUCT_MODULE_NAMES)
            else:
                self._core_info = QCC710BTCoreInfo(
                    custom_digits=self._io_struct,
                    custom_digits_modules=self.IO_STRUCT_MODULE_NAMES)
        return self._core_info

    @property
    def default_firmware_type(self):
        return BTDefaultZeagleFirmware

    @property
    def firmware_type(self):
        return BTDefaultZeagleFirmware

    @property
    def firmware_build_info_type(self):
        """returns class for build info"""
        raise IFirmwareBuildInfo.FirmwareSetupException

    @property
    def patch_build_info_type(self):
        return None

    @property
    def core_commands(self):
        return {}, []

    @property
    def name(self):
        """Name used in UI for this subsystem"""
        return "bt"

    @property
    def nicknames(self):
        return ("bt",)
    
