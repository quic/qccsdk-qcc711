JTAG_VERSION = 0x183

def factory(jtag_version, access_cache_type, io_struct=None):
    from ..qcc710_chip import QCC710Chip
    chip = QCC710Chip(access_cache_type=access_cache_type, 
                    raw_version=None,
                    io_struct=io_struct)
    return chip