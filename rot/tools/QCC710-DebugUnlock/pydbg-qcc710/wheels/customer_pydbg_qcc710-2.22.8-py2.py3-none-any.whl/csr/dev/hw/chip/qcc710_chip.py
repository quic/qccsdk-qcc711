############################################################################
# CONFIDENTIAL
#
# Copyright (c) 2020 Qualcomm Technologies International, Ltd.
#   %%version
#
############################################################################
"""
"""

from csr.wheels import autolazy, pack_unpack_data_le, iprint, wprint
from .base_chip import ChipBase, HasBTMixin, HasAppsMixin
from .mixins.has_jtag_swd_debug_trans import HasJtagSwdDebugTrans, HasMEMAP
from ..subsystem.generic_subsystem import GenericSubsystem
from csr.dev.hw.core.meta.i_layout_info import ArmCortexMDataInfo
from ..core.simple_space import SimpleRegisterSpace, SimpleDataSpace
from ..core.qcc710_core import QCC710BTCore, QCC710AppsCore
from ..core.tme_core import TMEDMISpace
from csr.dev.hw.debug_bus_mux import ARMDAP, GdbserverMux
from csr.dev.hw.debug.coresight import CoresightStickyError, CoresightDPAccessError
from csr.dev.hw.debug.swd import SWDInvalidACK
from csr.wheels import timeout_clock
import time
import os

class QCC710BTSubsystem(GenericSubsystem):
    """A subsystem for QCC710 bluetooth chips"""
    CORE_TYPE = QCC710BTCore
    ap_number = 1

class QCC710AppsSubsystem(GenericSubsystem, HasMEMAP):
    """
    The apps subsystem for QCC710 chips.
    """
    CORE_TYPE = QCC710AppsCore
    ap_number = 0


class QCC710Chip(ChipBase, HasBTMixin, HasAppsMixin,
                HasJtagSwdDebugTrans):
    """
    Simple support for QCC710.  This is a starting point; when more
    support is requested for QCC710 we will probably move QCC710Chip to a
    different base class that provides access to the full architecture.

    """
    AP_MAPPING = {"apps" :               ARMDAP.APIndex(0, "AHB"),
                  "bt" :                 ARMDAP.APIndex(1, "AHB"),
                  "system_fabric" :      ARMDAP.APIndex(2, "AHB"),
                  "tme_dmi" :            ARMDAP.APIndex(3, "AHB")}

    # BT is AP index 1
    GDBSERVER_PARAMS = {"jlink": {"bt": {"port": 2330, "device": "QCC710"},
                               "apps": {"port": 2331, "device": "QCC710"}}}

    DAP_PROPERTIES = {"interface": "swd",
                      "speed_khz": 4000,
                      "jtag_scan_chain": {"IRPre": 0, "DRPre": 0,
                                          "IRPost": 0, "DRPost": 0,
                                          "IRLenDevice": 4}
                      }

    BT_SUBSYSTEM_TYPE = QCC710BTSubsystem
    APPS_SUBSYSTEM_TYPE = QCC710AppsSubsystem

    def __init__(self, access_cache_type, io_struct=None, raw_version=None, 
                    is_blank_part=False):

        ChipBase.__init__(self, access_cache_type, io_struct,
                          raw_version=raw_version)
        HasBTMixin.__init__(self)
        HasAppsMixin.__init__(self)
        self._io_struct = io_struct
        self.is_blank_part = is_blank_part

        self._extra_aps = []
        for attr, ap_ind in self.AP_MAPPING.items():
            if attr not in ("apps","bt","tme_dmi"):
                ap = SimpleDataSpace(attr, length=1<<32,
                                    layout_info=ArmCortexMDataInfo(),
                                    cache_type=access_cache_type)
                setattr(self, attr, ap)
                self._extra_aps.append(ap)


    @property
    def name(self):
        return "QCC710"

    @property
    def raw_version(self):
        return None

    @property
    def dap(self):
        try:
            self._dap
        except AttributeError:
            self._dap = ARMDAP(self.cores + [self.tme_dmi] + self._extra_aps, self.AP_MAPPING,
                               # These are temporary values
                               properties=self.DAP_PROPERTIES)
        return self._dap.port

    def get_ap_flags(self):
        """
        The TME E21 should boot itself if this is a provisioned part; otherwise we need to do 
        a reset and not let the CPU run.
        """
        return {}

    @property
    def tme_dmi(self):
        try:
            self._dmi
        except AttributeError:
            self._dmi = TMEDMISpace(self._io_struct, self.access_cache_type)
        return self._dmi

    def enable_debug(self):
        try:
            self.debug.assert_power_request()
    
        except CoresightDPAccessError:
            pass
    
        trans = self.device.transport
        try:
            trans.api.connect_workaround
        except AttributeError:
            pass
        else:
            trans.api.connect_workaround("Cortex-M3", 0)



    def reset(self, reset_type="warm", core=None):
        """
        Warm or cold reset by writing to AON_PME_ROT_RESET
        Values given in AON HDD:
        https://projects.qualcomm.com/sites/QCC710/Shared%20Documents/SoC/HDD/AON_HDD.docm
        """
        known_reset_types = ("cold", "warm")
        if reset_type not in known_reset_types:
            raise ValueError("reset_type '{}' not recognised. Must be one of {}".
                             format(reset_type, ", ".join(known_reset_types)))
        # Write the reset register AON_PME_ROT_RESET.  It's visible through TME and
        # Apps.
        # NB To avoid dependency on the io_struct definitions we write the raw address 
        # of the register instead of using the register field object. 

        if core is None:
            core = self.apps_subsystem.core

        try:
            if reset_type == "cold":
                self.debug.dp.triggering_reset()
                core.dataw[0x50006028] = 0xd1ed1e
                t=timeout_clock()
                while timeout_clock() < t + 1:
                    pass
                self.debug.assert_power_request()

            else:
                core.fields.AON_PME_ROT_STATUS.ACTIVATE = 1
                self.debug.dp.triggering_reset()
                core.dataw[0x50006028] = 0xb4ebabe

        except CoresightStickyError:
            self.debug.clear_sticky_error()
        finally:
            self.debug.dp.reset_complete()

    def sleep(self):
        tme = self.tme_subsystem.core
        tme.fields.XTAL_CONF = 0xff
        tme.fields.XTAL_CTRL = 0xff
        tme.fields.XTAL_32K_OK = 1
        tme.fields.AON_PME_SOC_CONTROL.TLMM_ACTIVE = 1
        tme.fields.AON_PME_SOC_CONTROL.TEST_MODE_SHUTDOWN_EN = 1
        tme.fields.AON_PME_SOC_CONTROL.LFCLK = 0
        tme.fields.AON_PME_SOC_CONTROL.MFP_POSEDGE_DET = 1
        tme.fields.AON_PME_SOC_CONTROL.MFP_NEGEDGE_DET = 1
        tme.fields.AON_PME_BT_IRQ_EN.MFP_EDGE = 1
        tme.fields.AON_PME_SOC_OVERRIDES_VAL.BT_ARESET = 1
        tme.fields.AON_PME_SOC_OVERRIDES_EN.BT_ARESET = 1
        self.debug.clear_power_request()

    def wake(self, timeout=2, verbose=False):
        trans = self.device.transport

        swd = trans.get_raw_swd(verbose=verbose)

        old_speed = trans.reset_speed_khz(1000)

        # We have to keep doing the JTAG->SWD switching sequence
        # until we can read a DP register successfully
        awake = False
        attempts = 0
        t0 = time.time()
        while time.time() - t0 < timeout and not awake:
            for _ in range(100):
                swd.jtag_to_swd_switch()

            try:
                ctrl_stat = self.debug.dp.fields.CTRL_STAT.capture()
            except CoresightDPAccessError:
                attempts += 1
            else:
                self.debug.assert_power_request()
                awake = True
        
        if not awake:
            raise RuntimeError("Didn't manage to wake chip from sleep after "
                         "{} attempts in {} secs".format(attempts, time.time()-t0))

        trans.reset_speed_khz(old_speed)


    @property
    @autolazy
    def nvm(self):
        return QCC710NVM(self)


class QCC710NVM(object):

    TABLE_CMD_IDLE       = 0x00
    TABLE_CMD_READ       = 0x01
    TABLE_CMD_LOAD       = 0x02
    TABLE_CMD_WRITE      = 0x03
    TABLE_CMD_CLEAR_LOAD = 0x04

    NVM_QUEUE_DEPTH = 8
    NVM_SECTOR_SIZE         = 64

    TME_ID = 0
    APPS_ID = 1
    BT_ID = 2

    NUM_BLOCKS = 16
    DATA_BLOCK_BYTE_LENGTH = 0x8000
    DATA_BASE_ADDRESS = 0x10200000
    INFO_BASE_ADDRESS = 0x50400000
    INFO_BLOCK_BYTE_LENGTH = 0x80
    INFO_OTP_UB_ADDRESS = 0x50400200
    BT_BLOCKS = list(range(4))
    APPS_BLOCKS = list(range(4,14))
    TME_BLOCKS = list(range(14,16))


    def __init__(self, chip):

        self._chip = chip
        self.apps = chip.apps_subsystem.core
        self.bt = chip.bt_subsystem.core
        self.tme = chip.tme_subsystem.core

    def set_permissions(self, set_master=True):
        """
        This uses the Apps to set permissions on the NVM for the 
        Apps, BT and TME

        TODO Limit permissions to just the necessary blocks
        """

        regs = self.apps.fields

        # This is taken from a JLinkScript...
        # Once I understand the significance it probably wants to be in a different method
        regs.AON_PME_APPS_REMAP.OFFSET=0x10
        regs.AON_PME_APPS_RESET = 0xA9E0B16
        
        # Turn on the NVM
        regs.AON_PME_APPS_DEPEND_ACTIVE.NVM=3

        if set_master:
            regs.MASTER = 1 # Apps as master

        # Set up NVM MID permissions for the subsystems
        for ss_id, block_list in ((self.BT_ID, self.BT_BLOCKS),
                                    (self.APPS_ID, self.APPS_BLOCKS),
                                    (self.TME_ID, self.TME_BLOCKS)):
            for block in block_list:
                regs["REGION_MID_{}".format(block)] = ss_id

        # Set up NVM write permissions for the subsystems
        for ss_id, block_list in ((self.BT_ID, self.BT_BLOCKS),
                                  (self.APPS_ID, self.APPS_BLOCKS),
                                  (self.TME_ID, self.TME_BLOCKS)):
            access_0 = regs.ACCESS_0_0.capture(0)
            access_0.ID = ss_id
            access_0.RWX = 4 
            access_0_value = access_0.read()
            access_1 = regs.ACCESS_0_1.capture(0)
            access_1.ID = ss_id
            access_1.RWX = 4 | 1
            access_1_value = access_1.read()
            access_2 = regs.ACCESS_0_2.capture(0)
            access_2.ID = ss_id
            access_2.RWX = 2
            access_2_value = access_2.read()
            for block in block_list:
                regs["ACCESS_{}_0".format(block)] = access_0_value
                regs["ACCESS_{}_1".format(block)] = access_1_value
                regs["ACCESS_{}_2".format(block)] = access_2_value


    def write_data(self, addr, data_bytes, quiet=False, check_errors_inline=False):
        """
        Write data into RRAM through whichever subsystem owns the block(s) corresponding
        to the target address range
        """
        self.set_permissions()

        if (self.DATA_BASE_ADDRESS <= addr < 
                    self.DATA_BASE_ADDRESS + self.NUM_BLOCKS*self.DATA_BLOCK_BYTE_LENGTH):
            is_info = False
        elif (self.INFO_BASE_ADDRESS <= addr < self.INFO_BASE_ADDRESS + self.NUM_BLOCKS*self.INFO_BLOCK_BYTE_LENGTH):
            is_info = True
            if addr < self.INFO_OTP_UB_ADDRESS:
                raise ValueError("Address 0x{:x} invalid: Writing to OTP not supported".format(addr))
            addr -= self.INFO_BASE_ADDRESS
        else:
            raise ValueError("Address 0x{:x} is outside ")

        if not is_info:
            # Work out which subsystem owns the blocks that are to be written to
            start_block = (addr - self.DATA_BASE_ADDRESS) //self.DATA_BLOCK_BYTE_LENGTH
            end_block = (addr + len(data_bytes) - self.DATA_BASE_ADDRESS) //self.DATA_BLOCK_BYTE_LENGTH

            if start_block in self.BT_BLOCKS:
                assert (end_block in self.BT_BLOCKS)
                core = self.bt
                ss_id = self.BT_ID
            elif start_block in self.APPS_BLOCKS:
                assert (end_block in self.APPS_BLOCKS)
                core = self.apps
                ss_id = self.APPS_ID
            else:
                core = self.tme
                ss_id = self.TME_ID
        else:
            core = tme
            ss_id = self.TME_ID
        regs = core.fields
        ap = self._chip.debug.get_ap_of_subsystem(core)
        
        with ap.preselected_for_bus_access(): # we're indicating that all accesses are to the same AP
            # so DAP access can be optimised

            regs.MASTER = ss_id
            regs.ACCESS = ss_id
            regs.NVM_STATUS_ERROR_CLEAR = 0xff
            regs.INFO_BLOCK = int(is_info)


            # If the input data is not 64-bit aligned read the missing part(s) of the data
            if addr % 8 != 0:
                start_addr = (addr//8) *8
                data_bytes = core.data[start_addr:addr] + data_bytes
                addr = start_addr # now we're effectively writing from the 64-bit aligned address
            else:
                start_addr = addr
            end_addr = addr + len(data_bytes)
            if end_addr % 8 != 0:
                end_addr_aligned = (end_addr + 7)//8 * 8
                data_bytes += core.data[end_addr:end_addr_aligned]
                end_addr = addr + len(data_bytes)

            data_words = pack_unpack_data_le(data_bytes, from_width=8, to_width=32)

            if not quiet:
                iprint("Comparing supplied data with existing NVM contents...")
            # Now check which of the word-pairs actually need to be changed
            target_contents = core.dataw[start_addr:end_addr]
            indices_to_write = [i for i in range(0, len(data_words), 2) 
                                        if data_words[i:i+2] != target_contents[i:i+2]]
            if not quiet:
                iprint("Need to reprogram {} of {} bytes @ 0x{:x}".format(
                        len(indices_to_write)*8, len(data_bytes), start_addr))

            start_time = timeout_clock()

            dest_addr_base = (addr >> 3) & 0xffff
            
            # We exploit the fact that these three registers are contiguous in the address
            # space to make writing them more efficient
            LOAD_BUFFER_REGS_START = regs.LOAD_BUFFER_LSB.start_addr
            assert regs.LOAD_BUFFER_MSB.start_addr == LOAD_BUFFER_REGS_START + 4
            assert regs.LOAD_BUFFER_ADDRESS.start_addr == LOAD_BUFFER_REGS_START + 8

            def write_load_buffer(queued_addresses):
                # Trigger the actual write
                regs.TABLE = self.TABLE_CMD_WRITE
                while regs.NVM_STATUS.CMD_DONE == 0:
                    pass
                if check_errors_inline:
                    nvm_status_error = regs.NVM_STATUS_ERROR.capture()
                    if nvm_status_error != 0:
                        raise RuntimeError("NVM_STATUS_ERROR is set after writing "
                        "addresses in range [0x{:x}:0x{:x}]: {}".format(
                            queued_addresses[0], queued_addresses[-1],
                            repr(nvm_status_error)))


            data_index = 0
            write_queue_to_nvm = False
            queued_addresses = []
            queue_dest_sector = None
            for i, data_index in enumerate(indices_to_write):

                if not quiet and i != 0 and i % 512 == 0:
                    iprint(" reprogrammed {} bytes".format(i*8))

                dest_addr = dest_addr_base + data_index//2
                dest_sector = dest_addr // self.NVM_SECTOR_SIZE 
                # If this would land us in a new sector, we need to write what we have
                if queue_dest_sector is not None and dest_sector != queue_dest_sector:
                    # We need to write the load buffer before we can carry on because
                    # the next words to write are for a different sector
                    write_load_buffer(queued_addresses)
                    regs.TABLE = self.TABLE_CMD_CLEAR_LOAD
                    queued_addresses = []

                queue_dest_sector = dest_sector

                # Write the data into the load buffer
                buffer_load_words = [data_words[data_index],  # LOAD_BUFFER_LSB
                                     data_words[data_index+1],# LOAD_BUFFER_MSB
                                     dest_addr]               # LOAD_BUFFER_ADDRESS

                # Programme the load 
                core.dataw[LOAD_BUFFER_REGS_START:LOAD_BUFFER_REGS_START+12] = buffer_load_words

                # Trigger the load and wait for completion
                regs.TABLE = self.TABLE_CMD_LOAD
                while regs.NVM_STATUS.CMD_DONE == 0:
                    pass
                if check_errors_inline:
                    nvm_status_error = regs.NVM_STATUS_ERROR.capture()
                    if nvm_status_error != 0:
                        raise RuntimeError("NVM_STATUS_ERROR is set after loading to 0x{:x}: "
                                                "{}".format(dest_addr, repr(nvm_status_error)))

                queued_addresses.append(dest_addr)

                # If the buffer is full...
                if len(queued_addresses) == self.NVM_QUEUE_DEPTH:
                    # We need to write the buffer before we can carry on
                    write_load_buffer(queued_addresses)
                    regs.TABLE = self.TABLE_CMD_CLEAR_LOAD
                    queued_addresses = []
                    queue_dest_sector = None

            # Now write the final words, if any
            if queued_addresses != []:
                write_load_buffer(queued_addresses)

            nvm_status_error = regs.NVM_STATUS_ERROR.capture()
            if nvm_status_error != 0:
                raise RuntimeError("NVM_STATUS_ERROR is set on completion: {}".format(repr(nvm_status_error)))

            if not quiet:
                iprint("Reprogrammed NVM in {:0.1f}s".format(timeout_clock()-start_time))
                iprint("Checking target NVM contents...")

            # Now does NVM look right?
            if core.data[start_addr:end_addr] != data_bytes:
                time.sleep(1.0) # give it a sec and try again
                if core.data[start_addr:end_addr] != data_bytes:
                    if len(data_bytes) < 32:
                        wprint("Expected:  {}".format(data_bytes))
                        wprint("Actual: {}".format(core.data[start_addr:end_addr]))
                    raise RuntimeError("NVM doesn't contain expected bytes!")
            
            if not quiet:
                iprint("OK")
            

    def load_bin_file(self, base_addr, bin_file, quiet=False, check_errors_inline=False):
        """
        Load the contents of the supplied binary dump file at the given base address (which
        should be an address in NVM)
        """
        if not os.path.isfile(bin_file):
            raise ValueError("'{}' does not exist".format(bin_file))

        with open(bin_file,"rb") as bin_in:
            data = list(bytearray(bin_in.read()))

        self.write_data(base_addr, data, quiet=quiet, check_errors_inline=check_errors_inline)

    def load_hex_file(self, hex_file, quiet=False, check_errors_inline=False):
        """
        Load the contents of the supplied intelhex file (should contain addresses in NVM)
        """
        try:
            from intelhex import IntelHex
        except ImportError:
            raise ImportError("Couldn't import intelhex for loading .hex file.  "
                                    "Please install, e.g.'pip install intelhex'")
        
        hexdata = IntelHex(hex_file)
        binary_data = hexdata.tobinarray().tolist()
        segments = hexdata.segments()
        start = segments[0][0]
        for i, (lo,hi) in enumerate(segments):
            if not quiet:
                iprint("Loading data segment {} of {}".format(i, len(segments)))
            self.write_data(lo, binary_data[lo-start:hi-start],
                            quiet=quiet, check_errors_inline=check_errors_inline)




