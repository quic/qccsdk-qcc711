############################################################################
# CONFIDENTIAL
#
# Copyright (c) 2013 - 2016 Qualcomm Technologies International, Ltd.
#   %%version
#
############################################################################
import os
from .hip import HIP

class HydraInterfaceInfo (object):
    """\
    Hydra Chip Interface MetaData Interface.

    Provides access to interface descriptions held in directory of xml/hip.xsd
    files.
    
    Caches HIP file interface objects.    
    """
    def __init__(self, hip_dir):
        
        self._hip_dir = hip_dir
        self._hips = {} # cache of parsed hips - by file name
    
    def get_hip(self, hip_name):
        """\
        Get HIP interface by name.
        
        E.g. 'ccp' returns HIP wrapper for ccp.xml
        """
        # Create interface and cache on demand
        if hip_name not in self._hips:
            self._hips[hip_name] = self._create_hip(hip_name)
        return self._hips[hip_name]
       
    # Private
    
    def _create_hip(self, hip_name):
        """\
        Creates HIP interface to named hip file.
        """
        hip_path = os.path.join(self._hip_dir, (hip_name + '.xml'))
        return HIP(hip_path)
