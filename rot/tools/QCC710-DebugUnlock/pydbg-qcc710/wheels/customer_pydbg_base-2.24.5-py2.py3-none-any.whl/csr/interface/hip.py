############################################################################
# CONFIDENTIAL
#
# Copyright (c) 2013 - 2016 Qualcomm Technologies International, Ltd.
#   %%version
#
############################################################################
class HIP (object):
    """\
    Interface to host interface description file.

    Hides all gory xml details.
     
    Exposes general hip semantics (e.g. integer, enum, structure) but contains
    no application specifics. KEEP IT THAT WAY - OR ELSE.
    
    Ref: //depot/dot11/main/common/hostio/hip.xsd#18
    """
    def __init__(self, hip_xml_path):
                   
        # Use generated parser to deal with xml.
        #
        # We are still left to navigate the weird schema.
        #
        # N.B. Python property names are generated directly from hip.xsd
        #
        from .xml_parsers import hip_parser
        
        # Schema root is a "definitions" element
        #
        self._definitions = hip_parser.parse(hip_xml_path)        
    
    @property
    def types(self):
        """List of all type elements - includes enums & ..."""
        return self._definitions.type_
    
    @property
    def enums_by_name(self):
        """Index of all enum elements by name"""
        try:
            self._enums
        except AttributeError:
            self._create_indexes()
        
        return self._enums

    def _create_indexes(self):
        
        # The way to tell what type of element it is is by its properties! E.g.
        # HIP enum elements have one or more value elements, other hip types
        # don't!!@?
        # 
        self._enums = {}
        
        for type_ in self.types:
            if type_.value: # not empty - its logically an enum
                self._enums[type_.name] = type_

    def get_enum_dicts(self, type_list):
        '''
        Takes a list of enum names and returns a dictionary with each
        of those names being a dictionary of the enum elements as name:value
        '''
        interface = dict()
        for enum_type in type_list:
            interface[enum_type] = self.get_enum_dict(enum_type)
        return interface
        
    def get_enum_dict(self, enum_type):
        '''
        Create a dictionary of the enum elements as name:value
        '''
        enum = self.enums_by_name[enum_type]
        return dict((element.name, int(element.value, 0)) 
                                            for element in enum.value)
