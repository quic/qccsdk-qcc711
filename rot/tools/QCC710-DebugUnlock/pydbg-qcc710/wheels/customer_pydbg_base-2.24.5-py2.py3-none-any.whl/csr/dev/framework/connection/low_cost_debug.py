############################################################################
# CONFIDENTIAL
#
# Copyright (c) 2018-2020 Qualcomm Technologies International, Ltd.
#   %%version
#
############################################################################
from csr.wheels.global_streams import iprint
from ...hw.port_connection import MasterPort, PortConnection, AccessPath
from ...hw.address_space import ReadRequest, WriteRequest, AddressSpace
from ...hw.debug_bus_mux import TcMemWindowedRequest, TcMemRegBasedRequest
from ....wheels.bitsandbobs import words_to_bytes, bytes_to_words, TypeCheck,\
dwords_to_bytes, bytes_to_dwords
from ....transport.tctrans import TcTrans, TcError
from .trb import trb_aligned_read_helper, trb_aligned_write_helper
import platform
import sys
import os
from .connection_utils import SupportsGAIAApp

system = platform.system()
is_32bit = sys.maxsize == (1 << 31) - 1 

def load_tctrans(transport, dongle_id=None, earbud_designator=None):
    if system == "Windows":
        lib_path = "win32" if is_32bit else "win64"
        tctrans = TcTrans(override_lib_path=os.path.join(lib_path,"tctrans.dll"))
    else:
        tctrans = TcTrans(override_lib_path="libtctrans_shared.so")
    if dongle_id is not None:
        tctrans.open(dongle_id = dongle_id)
    else:
        devices = [dev for dev in tctrans.enumerate_devices() 
                                        if dev.transport == transport]

        if len(devices) == 1:
            tctrans.open(devices[0].id)
        elif len(devices) == 0:
            raise RuntimeError("No {} devices detected".format(transport))
        elif (len(devices) == 2 and 
              int(devices[0].id) - int(devices[1].id) in (1,-1) and 
              earbud_designator is not None):
            if earbud_designator not in ("L", "R"):
                  raise ValueError("earbud_designator must be 'L' or 'R'")
            # Left earbud is odd-numbered, right earbud is even-numbered.
            # The test above ensures that we have exactly one odd-numbered and one
            # even-numbered ID.
            if int(devices[0].id) % 2 == int(earbud_designator == "L"):
                # Either the designator is "L" and the ID is odd, or
                # the designator is not "L" and the ID is even.
                tctrans.open(devices[0].id)
            else:
                tctrans.open(devices[1].id)
        else:
            raise RuntimeError("Detected multiple {} devices with IDs {}"
                "specify device ID on command line".format(transport,
                                    ", ".join(dev.id for dev in devices)))
    return tctrans


def print_data_array(data):
    if len(data) < 4:
        iprint(" -> [%s]" % (",".join((hex(v) for v in data))))
    else:
        iprint(" -> [%s, ..." % (",".join((hex(v) for v in data))))


class LowCostDebugConnection(SupportsGAIAApp):
    """
    Interface to the two available low-cost debug transports - windowed and
    register-based access over toolcmd.  These are not distinguished to the user:
    Pydbg selects the best transport for each subsystem within TcMemMux
    """
    # From the specification - the IP port to use for the link
    DEFAULT_PORT_NUMBER = 13572

    def __init__(self, transport="usb2tc", dongle_id=None):
        
        earbud_designator = None # used for L or R with adbbbt
        # Dongle ID must be an ascii string
        if dongle_id:
            try:
                dongle_id = str(dongle_id)
            except UnicodeEncodeError:
                raise ValueError("'dongle_id' must be an ascii string")
        
        if transport.startswith("adbbt"):
            if dongle_id in ("l", "L", "r", "R"):
                earbud_designator = dongle_id.upper()
                dongle_id = None
            elif dongle_id is None:
                earbud_designator = "L" # left earbud by default
            else:
                try:
                    int(dongle_id)
                except ValueError:
                    raise RuntimeError("Expected 'adbbt', 'adbbt:L' or "
                                        "'adbbt:R', not '{}:{}'".format(transport, dongle_id))

        if transport == "adbbt":
            self._ip_port = self.DEFAULT_PORT_NUMBER
            self._start_adb_forwarding()
            self._start_gaia_debug_client_app()
        elif transport in ("usb", "usb2tc"):
            transport = "usbdbg"

        if transport == "usbdbg":
            enumeration_transport = "usb2tc"
        else:
            enumeration_transport = transport
        self._tctrans = load_tctrans(enumeration_transport, dongle_id=dongle_id,
                                     earbud_designator=earbud_designator)

        self.transport_type = transport
        

        self._win_master = self.WindowedMaster(self._tctrans)
        self._reg_master = self.RegBasedMaster(self._tctrans)
        
        self._verbose = False
        self.is_remote = False

    def reset_device(self, curator_unused, reset_type=None):
        """
        Reset the DUT. 
        :param curator_unused: Unused
        :param reset_type: Valid values are prefer_pbr, require_pbr, prefer_por 
            and require_por. However at this time USB DEBug only has one method 
            of provoking a reset which is via toolcmd, generating a post boot 
            reset. As such a NotImplementedError is raised if require_por passed.
        """

        if reset_type is None:
            reset_type = "require_pbr"
        
        reset_map = {"prefer_pbr": 'tctrans_reset',
                     "require_pbr": 'tctrans_reset',
                     "prefer_por": 'tctrans_reset',
                     "require_por": "notimplemented"}
            
        if reset_map[reset_type] == "tctrans_reset":
            self._tctrans.reboot_curator_cmd()
        else:
            raise NotImplementedError("{} is not a valid \
reset type for this configuration".format(reset_type))
        
    def reset(self, **kwargs):
        pass

    def toggle_verbose(self):
        self._win_master.toggle_verbose()
        self._reg_master.toggle_verbose()

    @property
    def windowed_master(self):
        return self._win_master

    @property
    def regbased_master(self):
        return self._reg_master
        
    def connect(self, chip):
        
        self._win_master.connect(chip.tc_mem_win_port)
        self._reg_master.connect(chip.tc_mem_reg_port)
    
    def get_chip_id(self):
        
        chip_version_reg = self._tctrans.read_windowed(0, 0xfe81, 1)
        return chip_version_reg[0]

    def block_read32(self, subsys, address, locations, block_id=0):
        return self._reg_master.block_read32(subsys, address, locations,
                                                            block_id=block_id)
        
    def block_read16(self, subsys, address, locations, block_id=0):
        return self._reg_master.block_read16(subsys, address, locations,
                                                            block_id=block_id)
        
    def xap_block_read(self, subsys, word_address, len_words):
        return self._win_master.xap_block_read(subsys, word_address, len_words)

    @property
    def tctrans(self):
        return self._tctrans
    
    def test_tunnel_interface(self):
        return TestTunnelAdaptor(self.tctrans, self.transport_type)

    class LowCostDebugMaster(MasterPort):
    
        def __init__(self, tctrans):
            
            MasterPort.__init__(self)
            self._tctrans = tctrans
            self._verbose = False
            self._dongle_id = self._tctrans.get_device_id()
            
        def toggle_verbose(self):
            old_value = self._verbose
            self._verbose = not self._verbose
            return old_value
    
        def execute_outwards(self, access_request):
    
            TypeCheck(access_request, self.REQUEST_TYPE)
    
            basic_request = access_request.basic_request
    
            if isinstance(basic_request, ReadRequest):
                self._read(access_request.subsys,
                           basic_request)
            elif isinstance(basic_request, WriteRequest):
                self._write(access_request.subsys,
                            basic_request)
        
        def connect(self, tc_chip_port):
            """\
            Logically connect self to the specified spi_space for access routing
            purposes.
    
            Also builds an extended AccessPath so that reachable AddressSpaces know
            "at a glance" what connections can reach them.
            """
            self._connection = PortConnection(self, tc_chip_port)
            self._access_path = AccessPath(0, self)
            self._access_path.extend()


    class WindowedMaster(LowCostDebugMaster):

        REQUEST_TYPE = TcMemWindowedRequest
    
        def _read(self, subsys_id, access_request):
            rq = access_request
            if self._verbose:
                iprint("Windowed read request for SS %d: %d words at 0x%x" %
                       (subsys_id, len(rq.region), rq.region.start))
            try: 
                rq.data = self._tctrans.read_windowed(subsys_id, rq.region.start,
                                                        len(rq.region))
            except TcError as e:
                raise AddressSpace.ReadFailure(": ".join((type(e).__name__,str(e))))
            if self._verbose:
                print_data_array(rq.data)
    
        def _write(self, subsys_id, access_request):
            rq = access_request
            if self._verbose:
                iprint("Windowed write request for SS %d: %d words at 0x%x" %
                       (subsys_id, len(rq.region), rq.region.start))
                print_data_array(rq.data)
            try:
                self._tctrans.write_windowed(subsys_id, rq.region.start,
                                             rq.data)
            except TcError as e:
                raise AddressSpace.WriteFailure(": ".join((type(e).__name__,str(e))))
            
        def xap_block_read(self, subsys_id, word_addr, word_len, block_id=0):
            
            self._tctrans.read_windowed(subsys_id, word_addr, word_len)


    class RegBasedMaster(LowCostDebugMaster):
    
        REQUEST_TYPE = TcMemRegBasedRequest
    
        def reader(self, subsys, block, addr, width, length):
            """
            Simple converter function that makes tctrans.read_regbased look the
            same as trbtrans.read, so the same helper function can be used to
            drive them both.
            """
            return self._tctrans.read_regbased(subsys, block, width, True, addr, length)
        def writer(self, subsys, block, addr, width, data):
            """
            Simple converter function that makes tctrans.write_regbased look the
            same as trbtrans.write, so the same helper function can be used to
            drive them both.
            """
            return self._tctrans.write_regbased(subsys, block, width, True, addr, data)
    
        def _read(self, subsys_id, access_request):
            
            try:
                trb_aligned_read_helper(subsys_id, access_request, 
                                        self.reader,
                                        verbose=self._verbose,
                                        dongle_id=self._dongle_id)
            except TcError as e:
                raise AddressSpace.ReadFailure(": ".join((type(e).__name__,str(e))))
            
        def _write(self, subsys_id, access_request):
            
            try:
                trb_aligned_write_helper(subsys_id, access_request, self.reader,
                                         self.writer,
                                         verbose=self._verbose, dongle_id=self._dongle_id)
            except TcError as e:
                raise AddressSpace.WriteFailure(": ".join((type(e).__name__,str(e))))

    
        def block_read32(self, subsys, address, locations, block_id=0):
            """
            Reads a block of dwords using a sequence of Debug Read Request 
            transactions. Similar to trbtrans.read().
            """
            return self._tctrans.read_regbased_32(subsys, block_id, True, 
                                                  address, locations)
        
        def block_read16(self, subsys, address, locations, block_id=0):
            """
            Reads a block of 16-bit words using a sequence of Debug Read Request 
            transactions. Similar to trbtrans.read().
            """
            return self._tctrans.read_regbased_16(subsys, block_id, True,
                                                  address, locations)


class TestTunnelAdaptorChannelError(RuntimeError):
    """
    Generic error handling test tunnel channels
    """

class TestTunnelAdaptorChannelAlreadyConnected(TestTunnelAdaptorChannelError):
    """
    The requested channel was already connected when it shouldn't have been
    """

class TestTunnelAdaptorChannelNotConnected(TestTunnelAdaptorChannelError):
    """
    The requested channel was not connected when it should have been
    """

def get_test_tunnel_adaptor(transport_type, tctrans=None):
    """
    Create a test tunnel interface for the given transport either using the supplied
    tctrans instance or creating a new one.
    """
    if tctrans is None:
        tctrans = load_tctrans(transport_type)
    return TestTunnelAdaptor(tctrans, transport_type)



class TestTunnelAdaptor:
    """
    Adaptation layer that provides an API suitable for insertion into TestTunnelProtocol
    based on the test tunnel API presented by tctrans.
    """

    # The host tools enumeration (not clear why this is different from the protocol
    # enumeration, but it is)
    _TC_TUNNEL_CLIENT_RFCLI=0
    _TC_TUNNEL_CLIENT_BTCLI=1
    _TC_TUNNEL_CLIENT_ACCMD=2
    _TC_TUNNEL_CLIENT_PTCMD=3
    _TC_TUNNEL_CLIENT_HOSTCOMMS=4
    _TC_TUNNEL_CLIENT_QACT=5
    _TC_TUNNEL_CLIENT_APPS0_FW_TEST=6
    _TC_TUNNEL_CLIENT_APPS1_FW_TEST=7
    _TC_TUNNEL_CLIENT_TRAP_API=8
    _TC_TUNNEL_CLIENT_AUDIO_DATA=9
    _TC_TUNNEL_CLIENT_CSB_SERVICE=10

    # The protocol enumeration
    control          = 0
    rfcli            = 1
    btcli            = 2
    apps0_fw_test    = 3
    apps1_fw_test    = 4
    trap_api         = 5
    accmd            = 6
    audio_data       = 7
    csb_service      = 8     
    production_test  = 9     
    host_comms       = 10

    HOST_TOOLS_CHANNEL = {control       : None,
                          rfcli         : _TC_TUNNEL_CLIENT_RFCLI,
                          btcli         : _TC_TUNNEL_CLIENT_BTCLI,
                          apps0_fw_test : _TC_TUNNEL_CLIENT_APPS0_FW_TEST,
                          apps1_fw_test : _TC_TUNNEL_CLIENT_APPS1_FW_TEST,
                          trap_api      : _TC_TUNNEL_CLIENT_TRAP_API,
                          accmd         : _TC_TUNNEL_CLIENT_ACCMD,
                          audio_data    : _TC_TUNNEL_CLIENT_AUDIO_DATA,
                          csb_service   : _TC_TUNNEL_CLIENT_CSB_SERVICE,
                          production_test : _TC_TUNNEL_CLIENT_PTCMD,
                          host_comms    : _TC_TUNNEL_CLIENT_HOSTCOMMS,
                          }

    _TC_TUNNEL_ISP_USBDBG=0xFF
    _TC_TUNNEL_ISP_TRB=0xFE
    _TC_TUNNEL_ISP_USBCC=0xFD
    _TC_TUNNEL_ISP_WIRELESS=0xFC

    HOST_TOOLS_TRANSPORT = {"usbdbg" : _TC_TUNNEL_ISP_USBDBG,
                            "usb2tc" : _TC_TUNNEL_ISP_USBDBG,
                            "trb"    : _TC_TUNNEL_ISP_TRB,
                            "usbcc"  : _TC_TUNNEL_ISP_USBCC,
                            "adbbt"  : _TC_TUNNEL_ISP_WIRELESS}

    class Channel:
        """
        Simple nested class representing a TestTunnel channel.  This
        consists of the tctrans TestTunnel object and an associated Receptor
        object for storing data returned by the code.
        """
        class Receptor:
            """
            File-like object that tctrans.TestTunnel can write incoming data
            to.  This provides a read-and-clear API for subsequently accessing
            the data.
            """
            def __init__(self):
                self._buffer = []
                self.closed = False # to satisfy the expected File-like API
            def write(self, data):
                self._buffer.append(list(data))
            def get_data(self):
                """
                Read and clear the current contents of the data buffer
                """
                if self._buffer:
                    return self._buffer.pop(0)

            def flush(self): # to satisfy the expected File-like API
                pass

        def __init__(self, channel_id, tctrans, transport_type):
            self._receptor = self.Receptor()
            self._channel = tctrans.createTestTunnel(transport_type, receptor=self._receptor)
            hosttools_id = TestTunnelAdaptor.HOST_TOOLS_CHANNEL[channel_id]
            hosttools_transport = TestTunnelAdaptor.HOST_TOOLS_TRANSPORT[transport_type]
            self._channel.tunnel_open(tctrans.get_device_id(), hosttools_id, hosttools_transport)

        def poll_for_rx(self):
            return self._receptor.get_data()

        @property
        def channel(self):
            return self._channel


    def __init__(self, tctrans, transport_type):
        self._tctrans = tctrans
        self._transport_type = transport_type
        self._channels = {}

    def connect_channel(self, channel_id):
        try:
            self._channels[channel_id]
        except KeyError:
            channel = self.Channel(channel_id, self._tctrans, self._transport_type) 
            self._channels[channel_id] = channel
        else:
            raise TestTunnelAdaptorChannelAlreadyConnected("Channel {} already "
                                            "connected!".format(channel_id))

    def disconnect_channel(self, channel_id):
        try:
            channel = self._channels[channel_id].channel
        except KeyError:
            raise TestTunnelAdaptorChannelNotConnected("Channel {} not "
                                            "connected!".format(channel_id))
        else:
            channel.tunnel_close()
            del self._channels[channel_id]

    def get_channel(self, channel_id):
        try:
            self._channels[channel_id]
        except KeyError:
            self.connect_channel(channel_id)
        return self._channels[channel_id].channel

    def poll_for_rx(self):
        """
        Return whatever has been received on any channel, reinserting the test tunnel 
        header as that is what clients of this method expect to see.  The header is just
        the tunnel ID in the first 8 bits of a 32-bit field.

        <!-- A test tunnel message consists of a header of fixed type and payload
        of a type determined by the Tunnel_Id in the header -->
        <type name="Test_Tunnel_Message" resource="PRIMITIVE">
        <field name="header">
            <type>Test_Tunnel_Header</type>
        </field>
        <field name="payload" discriminant="&amp;header.Tunnel_Id">
            <resource>Test_Tunnel_Payload</resource>
        </field>
        </type>

        <type name="Test_Tunnel_Header" resource="TYPE">
        <field name="Tunnel_Id">
            <type>Test_Tunnel_Id</type>
        </field>
        <field name="reserved" hidden="true">
            <type>uint8</type>
        </field>
        <field name="padding_bytes">
            <type>uint2</type>
        </field>
        <field name="reserved2" hidden="true">
            <type>uint14</type>
        </field>
        </type>
        """
        returned_data = []
        # What about the padding?  I guess that has been handled for us.
        for channel_id, channel in self._channels.items():
            response = channel.poll_for_rx()
            if response:
                returned_data += dwords_to_bytes([channel_id]) + response

        return returned_data