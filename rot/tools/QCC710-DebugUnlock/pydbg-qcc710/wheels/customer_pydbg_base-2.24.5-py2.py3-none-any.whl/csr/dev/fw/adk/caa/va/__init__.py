############################################################################
# CONFIDENTIAL
#
# Copyright (c) 2021 Qualcomm Technologies International, Ltd.
#
############################################################################

from .va import VA

PYDBG_PLUGIN_CONTAINER_NAME = "va"
PYDBG_PLUGIN_CONTAINER_CLASS = VA

__all__ = [PYDBG_PLUGIN_CONTAINER_NAME, PYDBG_PLUGIN_CONTAINER_CLASS]