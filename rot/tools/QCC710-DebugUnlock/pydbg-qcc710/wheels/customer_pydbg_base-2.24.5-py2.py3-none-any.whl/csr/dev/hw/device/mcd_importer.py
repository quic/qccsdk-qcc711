############################################################################
# CONFIDENTIAL
#
# Copyright (c) 2020 Qualcomm Technologies International, Ltd.
#   %%version
#
############################################################################

class McdDecodeTagNull(object):
    """\
    Base class for decoding an MCD tag entry to XCD text string format.
    """

    def __init__(self, tag_info):
        self._tag_info = tag_info
        self._lines = []

    def get_full_data_len(self):
        """ Number of words in the entire entry (tag + data). """
        return self._tag_info.full_len

    def _gen_str_block(self, data, block_length):
        """\
        Format the input data into a text block.
        """
        ret = []
        if not block_length:
            return ret
        for i in range(0, len(data), block_length):
            d = data[i:]
            d_len = min(len(d), block_length)
            if self._tag_info.is_32:
                ret.append(" ".join(["%04X%04X" % (d[i] & 0xFFFF, d[i+1] & 0xFFFF) for i in range(0, d_len, 2)]))
            else:
                ret.append(" ".join(["%04X" % (d[i] & 0xFFFF) for i in range(0, d_len, 1)]))
        return ret

    def _gen_str_header(self):
        """\
        Generate the header for the directive.
        """
        header_len = self._tag_info.hlen * (2 if self._tag_info.is_32 else 1)
        lines = [self._tag_info.directive]
        lines.extend(self._gen_str_block(self._tag_info.tag_data[:header_len], header_len))
        return [" ".join(lines)]

    def gen_str(self, endl='\n'):
        """\
        Generate a text string for the directive block.
        """
        return endl.join(self._lines) + endl if self._lines else ""

    def get_value(self, index):
        """\
        Return the value of the data at the specified index.
        """
        if self._tag_info.is_32:
            index *= 2
            ret = self._tag_info.tag_data[index] * 65536 + self._tag_info.tag_data[index + 1]
        else:
            ret = self._tag_info.tag_data[index]
        return ret

class McdDecodeTagHeadOnly(McdDecodeTagNull):
    """\
    Decoder for directives with a header only.
    """

    def __init__(self, tag_info):
        super(McdDecodeTagHeadOnly, self).__init__(tag_info)
        self._lines.extend(self._gen_str_header())

class McdDecodeTagDefault(McdDecodeTagHeadOnly):
    """\
    Decoder for directives with a header followed by a block of data.
    """

    def __init__(self, tag_info):
        super(McdDecodeTagDefault, self).__init__(tag_info)
        header_len = self._tag_info.hlen * (2 if self._tag_info.is_32 else 1)
        self._lines.extend(self._gen_str_block(self._tag_info.tag_data[header_len:], 16))

class McdDecodeTagRw(McdDecodeTagHeadOnly):
    """\
    Decoder for RW directive.
    """

    def _gen_str_header(self):
        fmt = "%08X" if self._tag_info.is_32 else "%04X"
        return [" ".join([
            self._tag_info.directive, fmt % self.get_value(0),
            "MASK", fmt % self.get_value(1),
            "VALUE", fmt % self.get_value(2)
        ])]

class McdDecodeErrorUnknownAtValue(ValueError):
    """\
    Error when an unknown AT value is passed.
    """
    pass

class McdDecodeTagAt(McdDecodeTagHeadOnly):
    """\
    Decoder for AT directive.
    """

    at_tag_names = {
        0   : "BC",
        1   : "BC7",
        2   : "UWB",
        3   : "UNIFI",
        4   : "MULTI",
        5   : "UNKNOWN",

        16  : "KALIMBA1",
        17  : "KALIMBA2",
        18  : "KALIMBA3",
        19  : "KALIMBA4",
        20  : "KALIMBA5",

        32  : "CORTEXM0"
    }

    at_tag_ids = { v:k for k,v in at_tag_names.items() }

    def _gen_str_header(self):
        try:
            lines = [" ".join([self._tag_info.directive, self.at_tag_names[self.get_value(0)]])]
        except KeyError:
            raise McdDecodeErrorUnknownAtValue("AT value %d is not known" % self.get_value(0))
        else:
            return lines

class McdDecodeTagAv(McdDecodeTagHeadOnly):
    """\
    Decoder for AV directive.
    """

    def chip_version(self):
        av = self.get_value(0)
        chip_major = (av >> 16) & 0x00FF
        chip_minor = (av >> 24) & 0x000F
        chip_variant = (av >> 28) & 0x000F
        return (chip_major, chip_minor, chip_variant)

class McdDecodeErrorUnknownSubSystem(ValueError):
    """\
    Error when an unknown SS value is passed.
    """
    pass

class McdDecodeTagSs(McdDecodeTagHeadOnly):
    """\
    Decoder for SS directive.
    """

    subsystem_names = {
        0 : "CURATOR",
        1 : "HOSTIO",
        2 : "BT",
        3 : "AUDIO",
        4 : "APP",
        5 : "PIO",
        6 : "WLAN",
        7 : "NFC"
    }

    subsystem_ids = { v:k for k,v in subsystem_names.items() }

    def _gen_str_header(self):
        try:
            self._ss_name = self.subsystem_names[self.get_value(0)]
        except KeyError:
            raise McdDecodeErrorUnknownSubSystem("Subsystem %d is not known" % self.get_value(0))
        return [" ".join([self._tag_info.directive, self._ss_name])]

class McdDecodeTagP(McdDecodeTagHeadOnly):
    """\
    Decoder for P directive.
    """

    def _gen_str_header(self):
        return [" ".join([self._tag_info.directive, "%u" % self.get_value(0)])]

class McdDecodeErrorUnknownRegister(IndexError):
    """\
    Error when an unknown Register index is passed.
    """

    pass

class McdDecodeTagR(McdDecodeTagHeadOnly):
    """\
    Decoder for R directive.
    """

    # These are encoded using binary to match the original documentation for
    # the processor.
    _arm_v6_reg_names = {
        0b00000:    "R0",
        0b00001:    "R1",
        0b00010:    "R2",
        0b00011:    "R3",
        0b00100:    "R4",
        0b00101:    "R5",
        0b00110:    "R6",
        0b00111:    "R7",
        0b01000:    "R8",
        0b01001:    "R9",
        0b01010:    "R10",
        0b01011:    "R11",
        0b01100:    "R12",
        0b01101:    "SP",
        0b01110:    "LR",
        0b01111:    "PC",
        0b10000:    "XPSR",
        0b10001:    "MSP",
        0b10010:    "PSP",

        0b10100:    "SPECIAL",

        32:         "DHCSR"
    }

    # Core register names for Kalimba3 (also covers 4 and 5)
    _kalimba3_reg_names = (
        "PC",
        "rMAC2",
        "rMAC1",
        "rMAC0",
        "rMAC24",
        "R0",
        "R1",
        "R2",
        "R3",
        "R4",
        "R5",
        "R6",
        "R7",
        "R8",
        "R9",
        "R10",
        "RLINK",
        "RFLAGS",
        "RMACB24",
        "I0",
        "I1",
        "I2",
        "I3",
        "I4",
        "I5",
        "I6",
        "I7",
        "M0",
        "M1",
        "M2",
        "M3",
        "L0",
        "L1",
        "L4",
        "L5",
        "RUNCLKS",
        "NUMINSTRS",
        "NUMSTALLS",
        "rMACB2",
        "rMACB1",
        "rMACB0",
        "B0",
        "B1",
        "B4",
        "B5",
        "FP",
        "SP"
    )

    # Core register names for XAP2
    _xap_reg_names = (
        "XAP_AH",
        "XAP_AL",
        "XAP_UXH",
        "XAP_UXL",
        "XAP_UY",
        "XAP_IXH",
        "XAP_IXL",
        "XAP_IY",
        "XAP_FLAGS",
        "XAP_PCH",
        "XAP_PCL",
        "XAP_BRK_REGH",
        "XAP_BRK_REGL",
        "XAP_BRK_INDEX",
        "XAP_RSVD_14",
        "XAP_RSVD_15"
    )

    # Map of base offset to name lookup
    _reg_base_map = (
        (0   , _xap_reg_names),         # XAP2
        (64  , []),                     # KALIMBA1
        (128 , []),                     # KALIMBA2
        (192 , _kalimba3_reg_names),    # KALIMBA3
        (256 , _kalimba3_reg_names),    # KALIMBA4
        (320 , _kalimba3_reg_names),    # KALIMBA5
        (384 , _arm_v6_reg_names)       # CORTEXM0
    )

    def _gen_str_header(self):
        self._reg_name = None
        val = self.get_value(0)
        for b in self._reg_base_map:
            if val >= b[0]:
                try:
                    self._reg_name = b[1][val - b[0]]
                except (KeyError, IndexError):
                    continue
                else:
                    break
        if self._reg_name is None:
            raise McdDecodeErrorUnknownRegister("Register number %d is not known" % val)

        if self._tag_info.is_32:
            r_val =  "%04X%04X" % (self._tag_info.tag_data[2] & 0xFFFF, self._tag_info.tag_data[3] & 0xFFFF)
        else:
            r_val =  "%04X" % (self._tag_info.tag_data[1] & 0xFFFF)

        return [" ".join([self._tag_info.directive, self._reg_name, r_val])]

class McdDecodeTagXcd(McdDecodeTagHeadOnly):
    """\
    Decoder for XCD directive.
    """

    def _gen_str_header(self):
        return ["".join([self._tag_info.directive, "%d" % self.get_value(0)])]

class McdDecodeTagUnsupported(McdDecodeTagHeadOnly):
    """\
    Decoder for tags that are not supported.
    """

    def _gen_str_header(self):
        return [" ".join(["# Unsupported directive: ", self._tag_info.directive])]

class McdTagInfo(object):
    """\
    Tag encoding and decoding.
    """

    _tag_decoders = {
        0   : { "directive":"NULL", "hlen":0,   "decode":McdDecodeTagNull},
        1   : { "directive":"AT",   "hlen":1,   "decode":McdDecodeTagAt},
        2   : { "directive":"AV",   "hlen":1,   "decode":McdDecodeTagAv},
        3   : { "directive":"BE",   "hlen":0,   "decode":McdDecodeTagDefault},
        4   : { "directive":"BS",   "hlen":2,   "decode":McdDecodeTagDefault},
        5   : { "directive":"CD",   "hlen":0,   "decode":McdDecodeTagUnsupported},
        6   : { "directive":"CM",   "hlen":0,   "decode":McdDecodeTagUnsupported},
        7   : { "directive":"CP",   "hlen":0,   "decode":McdDecodeTagUnsupported},
        8   : { "directive":"DC",   "hlen":2,   "decode":McdDecodeTagDefault},
        9   : { "directive":"DD",   "hlen":2,   "decode":McdDecodeTagDefault},
        10  : { "directive":"DE",   "hlen":2,   "decode":McdDecodeTagDefault},
        11  : { "directive":"DF",   "hlen":2,   "decode":McdDecodeTagDefault},
        12  : { "directive":"DJ",   "hlen":2,   "decode":McdDecodeTagDefault},
        13  : { "directive":"DK",   "hlen":5,   "decode":McdDecodeTagDefault},
        14  : { "directive":"DP",   "hlen":2,   "decode":McdDecodeTagDefault},
        15  : { "directive":"DR",   "hlen":2,   "decode":McdDecodeTagDefault},
        16  : { "directive":"DS",   "hlen":2,   "decode":McdDecodeTagDefault},
        17  : { "directive":"DX",   "hlen":2,   "decode":McdDecodeTagDefault},
        18  : { "directive":"II",   "hlen":1,   "decode":McdDecodeTagHeadOnly},
        19  : { "directive":"IS",   "hlen":0,   "decode":McdDecodeTagUnsupported},
        20  : { "directive":"P",    "hlen":1,   "decode":McdDecodeTagP},
        21  : { "directive":"R",    "hlen":2,   "decode":McdDecodeTagR},
        22  : { "directive":"RR",   "hlen":2,   "decode":McdDecodeTagDefault},
        23  : { "directive":"RW",   "hlen":0,   "decode":McdDecodeTagRw},
        24  : { "directive":"SS",   "hlen":1,   "decode":McdDecodeTagSs},
        25  : { "directive":"XCD",  "hlen":1,   "decode":McdDecodeTagXcd}
    }

    def __init__(self, data):
        """ Decode tag from the specified data. """
        self.id = (data[0] >> 11) & 0x1F
        self.is_32 = bool(data[0] & 0x400)
        self.item_count = data[0] & 0x1FF
        self.hlen = self._tag_decoders[self.id]["hlen"]
        self.directive = self._tag_decoders[self.id]["directive"]
        self.d_len = self.item_count * (2 if self.is_32 else 1)
        self.full_len = 1 + self.d_len
        self.tag_data = data[1:self.full_len]

    @classmethod
    def load_tag(cls, data):
        """\
        Generate a decoder object for the specified tag data.
        """
        info = cls(data)
        return cls._tag_decoders[info.id]["decode"](info)

    @classmethod
    def gen_tag_data(cls, directive, is_32, data):
        """\
        Generate tag data for the specified directive and data.
        """
        directive = directive.upper()
        directive_val = None

        for i in cls._tag_decoders.items():
            if i[1]["directive"] == directive:
                directive_val = i[0]
                break
        if directive_val is None:
            raise IndexError("Unknown Directive %s" % directive)

        tag = (directive_val & 0x1F) << 11 | (0x400 if is_32 else 0) | len(data)

        ret = [ tag ]
        for d in data:
            if is_32:
                ret.append((d >> 16) & 0xFFFF)
            ret.append(d & 0xFFFF)

        return ret

    @classmethod
    def gen_tag_data16(cls, directive, data):
        """\
        Generate 16-bit tag data for the specified directive and data.
        """
        return cls.gen_tag_data(directive, False, data)

    @classmethod
    def gen_tag_data32(cls, directive, data):
        """\
        Generate 32-bit tag data for the specified directive and data.
        """
        return cls.gen_tag_data(directive, True, data)

class McdImporter(object):
    def __init__(self, data):
        """\
        Load all tags from the input data (16-bit words).
        """
        # The current implementation does not include these tags (as they are
        # essentially constant data) so add them manually.
        self._tags = [
            McdTagInfo.load_tag(McdTagInfo.gen_tag_data16("XCD", [3])),
            McdTagInfo.load_tag(McdTagInfo.gen_tag_data16("AT", [McdDecodeTagAt.at_tag_ids["MULTI"]]))
        ]

        # Load all tags from the input data
        read_pos = 0
        count = len(data)
        while read_pos < count:
            # Generate decoder
            t = McdTagInfo.load_tag(data[read_pos:])
            # Add to the list of tags
            self._tags.append(t)
            # Increment the read offset by the number of words in the tag
            read_pos += t.get_full_data_len()

    def gen_xcd(self, endl='\n'):
        """\
        Generate XCD text.
        """
        return "".join([t.gen_str(endl) for t in self._tags])

    def write_to_file(self, f, endl='\n'):
        """\
        Write the XCD text to a file.
        """
        f.write(self.gen_xcd(endl))

    def write_to_filename(self, filename, endl='\n'):
        """\
        Write the XCD text to a file by name.
        """
        with open(filename, "w") as f:
            self.write_to_file(f, endl)

    @classmethod
    def create_from_binary_data(cls, data, endian='little'):
        """\
        Create the an MCD importer from a binary input source.
        """
        dw = [
            int.from_bytes(data[i:i+2], byteorder=endian, signed=False)
                for i in range(0, len(data), 2)
        ]
        return cls(dw)

    @classmethod
    def create_from_binary_file(cls, filename, endian='little'):
        """\
        Create the an MCD importer from a binary input filename.
        """
        data = []
        with open(filename, "rb") as f:
            data = list(f.read())
        return cls.create_from_binary_data(data, endian)
