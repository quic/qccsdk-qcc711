############################################################################
# CONFIDENTIAL
#
# Copyright (c) 2012 - 2016 Qualcomm Technologies International, Ltd.
#   %%version
#
############################################################################
"""\
Python framework for portable CSR device interfaces.

Abstracts device connection and debugging environment details.
"""

# Abstraction of the current python threading environment.
# See .runtime for implementations.
#
runtime = None
