############################################################################
# CONFIDENTIAL
#
# Copyright (c) 2015 - 2016 Qualcomm Technologies International, Ltd.
#   %%version
#
############################################################################
import time
import os

from csr.wheels.global_streams import iprint
from csr.wheels.bitsandbobs import dwords_to_words, \
                                    words_to_dwords, \
                                    bytes_to_words, \
                                    words_to_bytes, \
                                    dwords_to_bytes, \
                                    create_reverse_lookup, \
                                    bytes_to_dwords
                                    
from csr.interface.hydra_interface_info import HydraInterfaceInfo

def get_tctrans_test_tunnel(trans, verbose=False, hip_info=None):
    """
    Factory to instantiate the TcTrans test tunnel, if it is available.
    """
    try:
        trans.test_tunnel_interface
    except AttributeError:
        try:
            trans.trb
        except AttributeError:
            pass # fall through to the ISP-based test tunnel below
        else:
            # Open a separate TcTrans instance to enable Test Tunnel over Trb
            from csr.dev.framework.connection.low_cost_debug import get_test_tunnel_adaptor
            return TcTransTestTunnel(get_test_tunnel_adaptor("trb"), verbose=verbose, 
                                     hip_info=hip_info)
    else:
        # Use the existing tctrans interface
        return TcTransTestTunnel(trans.test_tunnel_interface(), verbose=verbose, 
                                    hip_info=hip_info)

def get_test_tunnel(core, ssid=4, isp=None, verbose=False):
    """
    Factory to instantiate the correct type of test tunnel interface.

    * If isp is None and the transport is either TcTrans or TRB, then we use the
    TcTransTestTunnel, which doesn't use any Hydra protocol information but instead
    connects to the test tunnel implementation provided by TcTrans
    * If isp is not None or the transport is not TcTrans or TRB, then we use the
    traditional explicit ISP-based TestTunnnel implementation.
    """
    if isp is None:
        trans = core.subsystem.chip.device.transport
        try:
            core.fw.build_info.get_hip
        except AttributeError:
            # Don't have build_info access - need to fall back to 
            hip_info = None
        else:
            hip_info = core.fw.build_info.get_hip()

        tt = get_tctrans_test_tunnel(trans, verbose=verbose, hip_info=hip_info)
        if tt is not None:
            return tt
    
class TcTransTestTunnel:
    """
    This class is intended to replace the original TestTunnel instance
    like-for-like if the transport-layer support is available.  However at
    present it is incomplete because it isn't clear what proportion of the
    existing TestTunnelProtocol API is still needed.
    """
    sig_ids = {    
        "accmd"            : 6,
        "audio_data"       : 7,
    }
    sig_names = {v:k for (k,v) in sig_ids.items()}

    def __init__(self, test_tunnel_adaptor, verbose=False, hip_info=None):

        self._tctrans_tt = test_tunnel_adaptor
        self._verbose = verbose
        self._handlers = {}
        if hip_info is None:
            # There's a copy of test_tunnel.xml in the same directory as this file
            # This is a bit of a bodge as it could get out of sync with the offical 
            # file but I don't see a better way to do it as we can't guarantee access
            # to the offical file, especially in customer contexts.
            hip_info = HydraInterfaceInfo(os.path.dirname(__file__))
        self.hip = hip_info.get_hip("test_tunnel")
        self.cmd_ids = self.hip.get_enum_dict("TEST_TUNNEL_CONTROL_ID")
        self.cmd_names = create_reverse_lookup(self.cmd_ids)
        self.rsp_names = create_reverse_lookup(
                           self.hip.get_enum_dict("Test_Tunnel_Response_Code"))


    def register_handler(self, tunnel_id, handler, byte_based=False):
        self._handlers[tunnel_id] = (handler, byte_based)

    def poll_for_rx(self):
        raw_bytes = self._tctrans_tt.poll_for_rx()
        pdu = {}
        if not raw_bytes:
            return
        tunnel_name = self.sig_names[raw_bytes[0]]
        pdu["tunnel_id"] = tunnel_name
        try:
            handler, byte_based = self._handlers[tunnel_name]
        except KeyError:
            handler, byte_based = None, True
        pdu["payload"] = raw_bytes[4:] if byte_based else bytes_to_dwords(raw_bytes[4:])
        if handler is not None:
            return handler(pdu)
        return pdu

    def send(self, tunnel_name, payload_dwords):
        if self._verbose:
            iprint("Test Tunnel[%s] Tx [%s]" %(tunnel_name, payload_dwords))
        tunnel_id = self.sig_ids[tunnel_name]
        channel = self._tctrans_tt.get_channel(tunnel_id)
        channel.tunnel_request(dwords_to_bytes(payload_dwords))

    def send_bytes(self, tunnel_name, payload_bytes, timeout=None):
        if self._verbose:
            iprint("Test Tunnel[%s] Tx [%s]" %(tunnel_name, payload_bytes))
        tunnel_id = self.sig_ids[tunnel_name]
        channel = self._tctrans_tt.get_channel(tunnel_id)
        channel.tunnel_request(payload_bytes)

    def connect(self, tunnel_name, timeout=None):
        tunnel_id = self.sig_ids[tunnel_name]
        self._tctrans_tt.connect_channel(tunnel_id)

    def disconnect(self, tunnel_name, timeout=None):
        tunnel_id = self.sig_ids[tunnel_name]
        self._tctrans_tt.disconnect_channel(tunnel_id)

    class TimeoutError(RuntimeError):
        pass