############################################################################
# CONFIDENTIAL
#
# Copyright (c) 2014 - 2016 Qualcomm Technologies International, Ltd.
#   %%version
#
############################################################################
import array
import random
import time
import socket
import os
import filecmp
from csr.wheels.global_streams import iprint
from csr.dev.fw.appcmd import AppCmd, AppCmdBufferWriter, AppCmdBufferReader
from csr.dev.fw.curator_buffer import CurBuffer
from csr.wheels.polling_loop import add_poll_function, remove_poll_function, \
                                    poll_loop
from csr.wheels.bitsandbobs import dwords_to_words
from csr.wheels.bitsandbobs import bytes_to_dwords, dwords_to_bytes,\
                                       bytes_to_words, words_to_bytes,\
                                       detect_ctrl_z,\
                                       create_reverse_lookup, \
                                       NameSpace, timeout_clock
from csr.transport.trb_raw import TimedLog
from csr.interface.hydra_interface_info import HydraInterfaceInfo

class ACCMDTestTunnelNotConnected(RuntimeError):
    """
    Raised when TransAudio has connect_accmd set to False, meaning ACCMDs are not
    supported.
    """

class TransAudio:
    def __init__(self, core, appcmd_or_test_tunnel, aud=None, connect_accmd=True):
        if isinstance(appcmd_or_test_tunnel, AppCmd):
            self._init_appcmd(appcmd_or_test_tunnel)
        else:
            self._init_test_tunnel(core, appcmd_or_test_tunnel, connect_accmd=connect_accmd)
        self._core = core
        self._connect_accmd = connect_accmd
        self._TimeoutError = appcmd_or_test_tunnel.TimeoutError
        if connect_accmd:
            if aud is not None:
                self.accmd_hip = aud.fw.env.build_info.get_hip("accmd")
                self.accmd_types_hip = aud.fw.env.build_info.get_hip("accmd_types")
                self.operator_hip = aud.fw.env.build_info.get_hip("operator")
                self.audio_hw = dict([(key.split("ACCMD_STREAM_DEVICE_")[1],value) 
                    for key, value in aud.fw.env.enums["audio_hardware"].items()])
            else:
                try:
                    self.accmd_hip = core.fw.env.build_info.get_hip("accmd")
                    self.accmd_types_hip = core.fw.env.build_info.get_hip("accmd_types")
                    self.operator_hip = core.fw.env.build_info.get_hip("operator")
                    self.audio_hw = dict([(key.split("AUDIO_HARDWARE_")[1],value) 
                        for key, value in core.fw.env.enums["audio_hardware"].items()])
                except AttributeError:
                    interface_info = HydraInterfaceInfo(os.path.realpath(os.path.dirname(__file__)))
                    self.accmd_hip = interface_info.get_hip("accmd")
                    self.accmd_types_hip = interface_info.get_hip("accmd_types")
                    self.operator_hip = interface_info.get_hip("operator")
                    self.audio_hw = dict([(key.split("AUDIO_HARDWARE_")[1],value) 
                        for key, value in core.fw.env.enums["audio_hardware"].items()])

            #accmd_id_objects = self.hip.enums_by_name["Accmd_Signal_Id"].value
            self.accmd_ids = self.accmd_hip.get_enum_dict("Accmd_Signal_Id")
            self.accmd_names = create_reverse_lookup(self.accmd_ids)
            self.accmd_streams = self.accmd_types_hip.get_enum_dict("Accmd_Stream_Device")
            self.accmd_status = create_reverse_lookup(
                            self.accmd_types_hip.get_enum_dict("Accmd_Status"))
            self.accmd_config_keys = self.accmd_types_hip.get_enum_dict("Accmd_Config_Key")
            self.operator_create_keys = self.operator_hip.get_enum_dict("OPERATOR_CREATE_EX")
        # STREAM_DEVICE is used by AudioData in the _create_endpoint method.
        if aud is not None:
            self.stream_hip = aud.fw.env.build_info.get_hip("stream")
        else:
            try:
                self.stream_hip = core.fw.env.build_info.get_hip("stream")
            except AttributeError:
                interface_info = HydraInterfaceInfo(os.path.realpath(os.path.dirname(__file__)))
                self.stream_hip = interface_info.get_hip("stream")
        self.stream_devices = self.stream_hip.get_enum_dict("STREAM_DEVICE")
        
        self._measure_cpu_usage = False
        self.verbose_debug = False

        # See //depot/hosttools/omnicli_1_0/omnicli/omnilib/if_tcpsocket/tcpsocket.h
        # for definition of MAGIC_SIGNAL_START
        self.TCP_MAGIC_SIGNAL_START = 0x13572468
        self._tcp_header_len = 8
        self.next_seq_num = 1

    def _init_appcmd(self, appcmd):
        self.appcmd = appcmd
        self.tt = None
        self.appcmd_cmds = self.appcmd.get_appcmd_dict_from_xml(["APPCMD_TEST_ID"])["APPCMD_TEST_ID"]
        self._APPCMD_TRANS_AUDIO_TEST_NUMBER = self.appcmd_cmds["Trans_Audio"]
        self.interface = self.appcmd.get_appcmd_dict_from_xml(["APPCMD_TEST_TRANS_AUDIO_TEST_ID"])
        self.test_no = self.interface["APPCMD_TEST_TRANS_AUDIO_TEST_ID"]
        self.command_buff = None
        self.response_buff = None

    def _init_test_tunnel(self, core, test_tunnel, connect_accmd):
        self.tt = test_tunnel
        self.tt_started = False
        if connect_accmd:
            self._tt_accmd_rsp_pending_list = []
            self.tt.register_handler("accmd", self._handle_accmd_test_tunnnel_pdu,
                                            byte_based=True)
        self.tt_data = AudioDataTestTunnel(core, self.tt)

    def _handle_accmd_test_tunnnel_pdu(self, pdu):
        self._tt_accmd_rsp_pending_list.append(dict(pdu))
        try:
            accmd = self.Accmd(self, pdu["payload"])
            pdu["params"] = accmd.params
            pdu["accmd_id"] = accmd.id
            pdu["accmd_name"] = accmd.name
            pdu["seq"] = accmd.sequence_num
            pdu.pop("payload")
        except (IndexError, KeyError):
            pass
        return pdu

    def _audio_appcmd_test(self, test, timeout=None, param_bytes=[]):
        try:
            return self.appcmd._test([self._APPCMD_TRANS_AUDIO_TEST_NUMBER,
                            self.cmd_len_dword(test, len(param_bytes))]
                                 + bytes_to_dwords(param_bytes),
                           timeout)
        except IndexError:
            iprint("Test %s params %s failed" % (test, param_bytes))

    def is_started(self, timeout=0.1):
        if self.tt:
            return self.tt_started
        return self._audio_appcmd_test("IS_STARTED", timeout)

    def start(self, timeout=0):
        if self.tt:
            if self.tt_started:
                return
            if self._connect_accmd:
                self.tt.connect("accmd")
            self.tt_started = True
        else:
            if self.is_started():
                return
            self._audio_appcmd_test("START", timeout)
            while not self.is_started():
                time.sleep(0.01)

    def stop(self, timeout=0):
        if self.tt:
            if self.tt_started:
                if self._connect_accmd:
                    self.tt.disconnect("accmd")
                self.tt_started = False
                self.tt_data.stop()
        else:
            self._audio_appcmd_test("STOP", timeout)
            while self.is_started():
                time.sleep(0.01)
            self.command_buff = None
            self.response_buff = None

    def play_file(self, filename):
        self._audio_appcmd_test("SETUP_LASH_UP_LINK", 0, [ord(a) for a in filename])

    def get_buffers(self):
        self._audio_appcmd_test("GET_BUFFERS")
        results = self.appcmd.get_results(2)
        self.command_buff = AppCmdBufferWriter(self.appcmd, results[0])
        self.response_buff = AppCmdBufferReader(self.appcmd, results[1])

    def cmd_len_dword(self, cmd_str, param_len):
        ''' Return a uint32 combination of command number and param length '''
        return self.test_no[cmd_str] | param_len<<16

    class TestError(RuntimeError):
        pass

    def send_command(self, bytes, timeout=0.1):
        if self.tt:
            if self._connect_accmd:
                self.tt.send_bytes("accmd", bytes)
            else:
                raise ACCMDTestTunnelNotConnected("Can't send ACCMD because this is a non-ACCMD connection")
        else:
            if self.command_buff is None:
                self.get_buffers()
            self.command_buff.write_msg(bytes)
            self._audio_appcmd_test("TRIGGER_SEND", timeout, bytes)

    def get_response(self, timeout=0):
        if timeout:
            start_time = timeout_clock()
        while self.tt:
            self.tt.poll_for_rx()
            if self._tt_accmd_rsp_pending_list:
                return self._tt_accmd_rsp_pending_list.pop(0)["payload"]
            if timeout:
                if timeout_clock() - start_time > timeout:
                    raise self._TimeoutError
            else:
                return None
        # Not test tunnel so we are using appcmd
        if self.response_buff is None:
            self.get_buffers()
        if not self.response_buff.num_msgs:
            return None
        return self.response_buff.read_msg()

    class AccmdException(Exception):
        def __init__(self, str):
            self.str = str
        def __str__(self):
            return self.str

    def accmd_send(self, cmd_name, seq_num=None, param_words=[], response_name=None):
        '''
        Send an ACCMD and wait for the response.
        
        Note. 
        The on chip Audio Control module may asynchronously send ACCMDs to
        audio, the responses to these will be returned through the test tunnel 
        so this method needs to expect the 'unexpected'. 
        
        Currently it is known that only a single PS_REGISTER is likely to be 
        encountered. If(when) the Audio subsystem starts making heavy use of  
        PSKEYs then an intelligent scheme for handling these will be needed.
        However for now a single retry is 'good enough'. 
        '''
        if not self._connect_accmd:
            raise ACCMDTestTunnelNotConnected("accmd_send not supported when "
                                        "ACCMD test tunnel is not connected")

        SEQ_NUM_MASK = 0xFF
        if seq_num == None:
            seq_num = self.next_seq_num
            self.next_seq_num += 1
            self.next_seq_num &= SEQ_NUM_MASK
        cmd_words = [ self.accmd_ids[cmd_name], 
                        len(param_words)*2, seq_num ] + param_words
        self.send_command(words_to_bytes(cmd_words))
        response_bytes = self.get_response(0.5)
        response = self.Accmd(self, response_bytes)
        
        happy = True
        
        if response.sequence_num != seq_num:
            happy = True
            iprint("Note: The response: Seq. Num. %d received didn't match %d"%(response.sequence_num,seq_num))
            seq_num = response.sequence_num
            
        if response_name and response.name != response_name:
            happy = False
            iprint("Note: The response: Resp. name %s received didn't match %s"%(response.name, response_name))
             
        if (not happy):  
            #Look again for the right response.. 
            iprint("Ignoring first response and looking again.")        
            
            response_bytes = self.get_response(0.2)
            response = self.Accmd(self, response_bytes)
        
        #If still didn't get expected response complain loudly.
        if response.sequence_num != seq_num:
            raise self.TestError("Expected response sequence number %d, got %d"
                                    % (seq_num, response.sequence_num))
        if response_name and response.name != response_name:
            raise self.TestError("Received response %s, expected %s"
                                    % (response.name, response_name))

        return response

    def create_sink(self, type, endpoint=0, meta_len=4, params=[]):
        ''' Create a Sink endpoint by starting the appropriate audio
        service.        '''
        if self.verbose_debug:
            iprint(".... Creating input service %d" % endpoint)
        return self._create_endpoint(1, type, endpoint, meta_len, params)

    def create_source(self, type, endpoint=0, meta_len=4, params=[]):
        ''' Create a Source endpoint by starting the appropriate audio
        service.        '''
        if self.verbose_debug:
            iprint(".... Creating output service %d" % endpoint)
        return self._create_endpoint(0, type, endpoint, meta_len, params)

    def _create_endpoint(self, sink, type, endpoint, meta_len, params):
        if self.verbose_debug:
            iprint("Create_Link_Req", [ sink | (meta_len<<8), self.stream_devices[type], endpoint] + params)
        self.tt_data.send("Create_Link_Req",
                    [ sink | (meta_len<<8), self.stream_devices[type], endpoint]
                                                                    + params)
        while True:
            resp = self.tt_data.wait_for_response(0.2)
            if resp:
                if resp["id"] == "Create_Cfm":
                    resp.pop("id")
                    return resp
            else:
                raise self._TimeoutError

    def destroy_sink(self, endpoint):
        self.tt_data.send("Destroy_Link_Req", [endpoint])
        while True:
            resp = self.tt_data.wait_for_response(0.2)
            if resp:
                if resp["id"] == "Destroy_Cfm":
                    resp.pop("id")
                    return resp
                iprint(resp)
            else:
                raise self._TimeoutError

    def destroy_source(self, endpoint):
        self.destroy_sink(endpoint)

    def _get_version_string(self):
        response = self.accmd_send("GET_FIRMWARE_ID_STRING_REQ",
                                   response_name="GET_FIRMWARE_ID_STRING_RESP")
        ver_string = "".join([chr(a) for a in words_to_bytes(response.params[1:])])
        return ver_string

    def _get_version_number(self):
        response = self.accmd_send("GET_FIRMWARE_VERSION_REQ",
                                     response_name="GET_FIRMWARE_VERSION_RESP")
        ver_num = response.params[0]
        return ver_num

    def get_version(self):
        iprint("Audio service firmware: '%s' version number 0x%x" % (
                                            self._get_version_string(),
                                            self._get_version_number()))

    def run_download_self_test(self, download_op):
        START_SELF_TEST=1
        resp = self.accmd_send("OPERATOR_MESSAGE_REQ",
                   param_words=[download_op.id, START_SELF_TEST],
                   response_name = "OPERATOR_MESSAGE_RESP")
        iprint("Download OP message resp %s (%s)" % (resp.params, resp.status))
        if resp.params[1] == 0x600D:
            iprint("Download self test successful!")
            return True
        else:
            iprint("Error. Something went wrong!")
            return False

    def remove_download_self_test(self, kcs_id):
        self.accmd_ids["CAP_DOWNLOAD_REMOVE_KCS_REQ"] = 0x20
        self.accmd_names[0x20] = "CAP_DOWNLOAD_REMOVE_KCS_REQ"
        resp = self.accmd_send("CAP_DOWNLOAD_REMOVE_KCS_REQ",
                   param_words=[kcs_id],
                   response_name = "STANDARD_RESP")
        iprint(resp)
        if resp.status != "OK":
            raise Exception("Test failed")

    def test_cap_download(self, data_sink_file_name):
        proc_id = 0
        self.start(0.2)
        for i in range(10):
            self._get_version_string()
            self._get_version_number()
        backup = self.accmd_streams["TESTER"]
        # Temporarily change the value of TESTER while CAP_DOWNLOAD isn't part of accmds.xml
        self.accmd_streams["TESTER"] = 0x0F
        sink = self.create_sink("TESTER", meta_len=0, endpoint=proc_id)["endpoint_id"]
        self.accmd_streams["TESTER"] = backup
        if self.tt:
            start_time = time.time()
            self.start_cpu_usage_measurement()
            self.tt_data.start_sink_from_file(sink, data_sink_file_name, meta=0)
            file_bytes = self.tt_data.endpoint_files[sink]["total_bytes"]
            self.tt_data.wait_for_file_complete([sink])
            cpu_usage = self.get_cpu_usage()[1]
            end_time = time.time()
            iprint("CPU Usage %3g %%" % cpu_usage)
            iprint("Transfer took %3g sec = %d kbps" % (end_time-start_time,
                           float(file_bytes*8)/((end_time-start_time)*1000.0)))
            iprint(self.destroy_sink(sink))
            time.sleep(1)
            for i in range(10):
                download_self_test_op = self.create_download_self_test_op()
                if self.run_download_self_test(download_self_test_op) == False:
                    raise Exception("Test failed")
                self.destroy_download_self_test_op(download_self_test_op)
            iprint("Remove KCS")
            self.remove_download_self_test(1)
        iprint("Capability download test complete.")

    def test(self):
        test_pass = True
        
        self.start(0.2)
        for dummy in range(10):
            if not self._get_version_string():
                test_pass = False
            if not self._get_version_number():
                test_pass = False

        for meta_len in [0, 2, 3, 4, 5, 6, 7, 8]:
            if not self.test_file_loopback(meta_len = meta_len):
                test_pass = False
            
        if not self.test_retimer():
            test_pass = False
        self.stop()
        iprint("Audio test complete: %s" % ("FAIL", "PASS")[test_pass])
            
    def create_loopback_link(self, meta_len):
        copy_op = self.create_copy_operator()
        ep_src = self.create_source("TESTER", copy_op.src_ep, meta_len)["endpoint_id"]
        ep_sink = self.create_sink("TESTER", copy_op.sink_ep, meta_len)["endpoint_id"]
        self._connect_endpoints(ep_sink, ep_src, copy_op)
        return ep_src, ep_sink, copy_op

    def test_file_loopback(self, src_file_name=None, meta_len=4, endpoint=0, test_flow_control=False):
        test_pass = True
        
        ep_src, ep_sink, copy_op = self.create_loopback_link(meta_len)
                
        if self.tt:
            data_sink_file_name = src_file_name or "test_src.txt"
            data_src_file_name = "audio_source_rx_file.txt"

            start_time = time.time()
            if self._measure_cpu_usage:
                self.start_cpu_usage_measurement()
            
            if test_flow_control:
                tt_buffer = self._core.fw.env.cus["test_tunnel.c"].localvars[
                         "tt_data"].isp_host.isp_link_context.tx_buf.handle.value & 0xff
                saved_offset = self._core.subsystem.mmu.handleTable[tt_buffer].bufferOffset 
                self._core.subsystem.mmu.handleTable[tt_buffer].bufferOffset.value = saved_offset + 2
                iprint("Flow controlling output buffer at offset 0x%x" % saved_offset)
                 
            self.tt_data.start_sink_from_file(ep_sink, data_sink_file_name, meta=meta_len)

            file_bytes = self.tt_data.endpoint_files[ep_sink]["total_bytes"]

            self.tt_data.start_file_from_source(ep_src, data_src_file_name,
                                                        max_bytes=file_bytes)
            if test_flow_control:
                fc_start_time = time.time()
                while time.time() < fc_start_time + 0.1:
                    self.tt_data.wait_for_file_complete_poll([ep_sink, ep_src])
                iprint("Sent %d bytes, received %d bytes with flow control blocked" % (
                      self.tt_data.endpoint_files[ep_sink]["bytes_sent"],
                      self.tt_data.endpoint_files[ep_src]["bytes"]))
                self._core.subsystem.mmu.handleTable[tt_buffer].bufferOffset.value = saved_offset
                
            self.tt_data.wait_for_file_complete([ep_sink, ep_src])
            if self._measure_cpu_usage:
                cpu_usage = self.get_cpu_usage()[1]
            end_time = time.time()
            if self._measure_cpu_usage:
                iprint("CPU Usage %3g %%" % cpu_usage)
            iprint("Transfer took %3g sec = %d kbps" % (end_time-start_time,
                           float(file_bytes*8)/((end_time-start_time)*1000.0)))
            if filecmp.cmp(data_sink_file_name, data_src_file_name, shallow=0):
                iprint("Files compared OK")
                try:
                    os.remove(data_src_file_name)
                except WindowsError:
                    iprint("Failed to delete dest file %s" % data_src_file_name)
            else:
                iprint("FAIL: Files %s and %s differ" % (data_sink_file_name,
                                                            data_src_file_name))
                test_pass = False

        self.destroy_copy_operator(copy_op)
        self.destroy_sink(ep_sink)
        self.destroy_source(ep_src)
        
        return test_pass

    def test_retimer(self):
        test_pass = True
        ep_src, ep_sink, copy_op = self.create_loopback_link(4)
        if not self.tt_data.test_timed(ep_sink, [ 120, 121, 122, 123, 126, 127, 128]):
            test_pass = False
            iprint("Timed test FAILED")
        if not self.tt_data.test_timed(ep_sink, [ 160, 180, 185, 224, 246, 250, 251, 252, 290]):
            test_pass = False
            iprint("Timed test FAILED")
        self.destroy_copy_operator(copy_op)
        self.destroy_sink(ep_sink)
        self.destroy_source(ep_src)
        return test_pass

    def test_aptx(self, src_file_name=None, meta_len=0, endpoint=0):
        iprint("+++++++++ APTX TEST +++++++++ ")
        self.start(0.2)
        for i in range(10):
            self._get_version_string()
            self._get_version_number()

        aptx_op = self.create_aptx_operator()

        ep_src_L = self.create_source("TESTER", meta_len=meta_len,
                                       endpoint=aptx_op.src_ep_L)["endpoint_id"]
        iprint("---- Left Output Terminal created from %d to %d" % (ep_src_L,aptx_op.src_ep_L))

        ######raw_input()
        ep_src_R = self.create_source("TESTER",  meta_len=meta_len,
                                        endpoint=aptx_op.src_ep_R)["endpoint_id"]
        iprint("---- Right Output Terminal created from %d to %d" % (ep_src_R,aptx_op.src_ep_R))

        ######raw_input()
        ep_sink = self.create_sink("TESTER",  meta_len=meta_len,
                                    endpoint=aptx_op.sink_ep)["endpoint_id"]
        iprint("---- Input Terminal created from %d to %d" % (aptx_op.sink_ep,ep_sink))

        ######raw_input()
        self._connect_aptx_endpoints(ep_sink, ep_src_L, ep_src_R, aptx_op)
        iprint("---- Endpoints connected")

        if self.tt:
            data_sink_file_name  = src_file_name or "test_src.txt"
            data_left_file_name  = "audio_left_rx_file.txt"
            data_right_file_name = "audio_right_rx_file.txt"

            start_time = time.time()
            self.start_cpu_usage_measurement()

            self.tt_data.start_sink_from_file(ep_sink, data_sink_file_name, meta=meta_len)
            file_bytes = self.tt_data.endpoint_files[ep_sink]["total_bytes"]
            iprint("---- started sink from file    %d bytes" % file_bytes)
            ######raw_input()

            self.tt_data.start_file_from_source(ep_src_L, data_left_file_name,
                                                        max_bytes=file_bytes)
            iprint("---- started file from source ep_src_L")
            ######raw_input()

            self.tt_data.start_file_from_source(ep_src_R, data_right_file_name,
                                                        max_bytes=file_bytes)
            iprint("---- started file from source ep_src_R")
            ######raw_input()

            iprint("---- waiting for file complete....")
            self.tt_data.wait_for_file_complete([ep_sink, ep_src_L, ep_src_R])
            cpu_usage = self.get_cpu_usage()[1]
            end_time = time.time()
            iprint("CPU Usage %3g %%" % cpu_usage)
            iprint("Transform complete -- took %3g sec = %d kbps" % (end_time-start_time,
                           float(file_bytes*8)/((end_time-start_time)*1000.0)))
            iprint(os.path.abspath(data_left_file_name))

#            if filecmp.cmp(data_sink_file_name, data_left_file_name, shallow=0):
#                iprint("Files compared OK")
#                try:
#                    os.remove(data_left_file_name)
#                except WindowsError:
#                    iprint("Failed to delete dest file %s" % data_left_file_name)
#            else:
#                iprint("FAIL: Files %s and %s differ" % (data_sink_file_name,)
#                                                            data_left_file_name)

        self.destroy_sink(ep_sink)
        self.destroy_source(ep_src_L)
        self.destroy_source(ep_src_R)
        self.destroy_copy_operator(aptx_op)
        iprint("APTX Audio test complete.")

    def source_from_operator_terminal(self, operator, terminal_num):
        # Magic formula from the audio team.
        # TODO - Replace with
        # ACCMD STREAM_GET_SOURCE_REQ OPERATOR, opid, terminal
        # when B-193787 is fixed
        return operator + 0x2000 + terminal_num

    def sink_from_operator_terminal(self, operator, terminal_num):
        # Magic formula from the audio team.
        # TODO - Replace with
        # ACCMD STREAM_GET_SINK_REQ OPERATOR, opid, terminal
        # when B-193787 is fixed
        return operator + 0xa000 + terminal_num

    def create_operator(self, cap_id):
        resp = self.accmd_send("CREATE_OPERATOR_REQ",
                               param_words= [cap_id],
                               response_name="CREATE_OPERATOR_RESP")
        if (resp.status == "OK"):
            op = NameSpace()
            return resp.params[0]
        else:
            raise self.AccmdException(resp.status)
    
    def create_operator_ex(self, cap_id, pri=None, proc_id=None):
        create_op_ex_params = []
        num_keys = 0
        
        if pri:
            create_op_ex_params += [
                self.operator_create_keys["OPERATOR_CREATE_OP_PRIORITY"],
                pri & 0xFFFF,
                (pri >> 16) & 0xFFFF
            ]
            num_keys += 1
        if proc_id:
            create_op_ex_params += [
                self.operator_create_keys["OPERATOR_CREATE_PROCESSOR_ID"],
                proc_id & 0xFFFF,
                (proc_id >> 16) & 0xFFFF
            ]
            num_keys += 1
        
        if num_keys == 0:
            return self.create_operator(cap_id)
        else:
            resp = self.accmd_send("CREATE_OPERATOR_EX_REQ",
                                   param_words= [cap_id, num_keys] + create_op_ex_params,
                                   response_name="CREATE_OPERATOR_EX_RESP")
            if resp.status == "OK":
                op = NameSpace()
                return resp.params[0]
            else:
                raise self.AccmdException(resp.status)
    
    def send_operator_message(self, op_id, msg_words):
        resp = self.accmd_send("OPERATOR_MESSAGE_REQ",
                   param_words = [op_id] + msg_words,
                   response_name = "OPERATOR_MESSAGE_RESP")
        if (resp.status != "OK"):
            raise self.AccmdException(resp.status)

    def start_operators(self, op_ids):
        resp = self.accmd_send("START_OPERATORS_REQ",
                               param_words=[len(op_ids)] + op_ids,
                               response_name="START_OPERATORS_RESP")
        if (resp.status != "OK"):
            raise self.AccmdException(resp.status)

    def stop_operators(self, op_ids):
        resp = self.accmd_send("STOP_OPERATORS_REQ",
                               param_words=[len(op_ids)] + op_ids,
                               response_name="STOP_OPERATORS_RESP")
        if (resp.status != "OK"):
            raise self.AccmdException(resp.status)

    def destroy_operators(self, op_ids):
        resp = self.accmd_send("DESTROY_OPERATORS_REQ",
                               param_words= [len(op_ids)] + op_ids,
                               response_name="DESTROY_OPERATORS_RESP")
        if (resp.status != "OK"):
            raise self.AccmdException(resp.status)

    def connect_endpoints(self, src_ep, sink_ep):
        resp = self.accmd_send("STREAM_CONNECT_REQ",
                   param_words= [src_ep, sink_ep],
                   response_name = "STREAM_CONNECT_RESP")
        if (resp.status == "OK"):
            return resp.params[0]
        else:
            raise self.AccmdException(resp.status)

    def transform_disconnect(self, transform_id):
        resp = self.accmd_send("STREAM_TRANSFORM_DISCONNECT_REQ",
                               param_words = [transform_id],
                               response_name = "STANDARD_RESP")
        if (resp.status != "OK"):
            raise self.AccmdException(resp.status)

    def stream_configure(self, ep, key_name, value):
        resp = self.accmd_send("STREAM_CONFIGURE_REQ",
                               param_words = [ep, self.accmd_config_keys[key_name], (value & 0xFFFF), (value & 0xFFFF0000) >> 16],
                               response_name = "STANDARD_RESP")
        if (resp.status != "OK"):
            raise self.AccmdException(resp.status)

    def stream_get_source(self, device_name, instance, channel):
        c = ord(channel.upper()) - ord('A')
        resp = self.accmd_send("STREAM_GET_SOURCE_REQ",
                               param_words = [self.accmd_streams[device_name], instance, c],
                               response_name = "STREAM_GET_SOURCE_RESP")
        if (resp.status == "OK"):
            return resp.params[0]
        else:
            raise self.AccmdException(resp.status)

    def stream_get_sink(self, device_name, instance, channel):
        c = ord(channel.upper()) - ord('A')
        resp = self.accmd_send("STREAM_GET_SINK_REQ",
                               param_words = [self.accmd_streams[device_name], instance, c],
                               response_name = "STREAM_GET_SINK_RESP")
        if (resp.status == "OK"):
            return resp.params[0]
        else:
            raise self.AccmdException(resp.status)

    def stream_sync_sid(self, ep1, ep2):
        resp = self.accmd_send("STREAM_SYNC_SID_REQ",
                                param_words = [ep1, ep2],
                                response_name = "STANDARD_RESP")
        if (resp.status != "OK"):
            raise self.AccmdException(resp.status)

    def create_copy_operator(self):
        copy_op = NameSpace()
        resp = self.accmd_send("CREATE_OPERATOR_REQ",
                               param_words= [ 1],
                               response_name="CREATE_OPERATOR_RESP")
        copy_op.id = resp.params[0]
        copy_op.src_ep = self.source_from_operator_terminal(copy_op.id, 0)
        copy_op.sink_ep = self.sink_from_operator_terminal(copy_op.id, 0)
        iprint("Copy operator 0x%x created, src_ep=%d, sink_ep=%d" % (copy_op.id,copy_op.src_ep,copy_op.sink_ep))
        return copy_op

    def create_download_self_test_op(self):
        download_op = NameSpace()
        resp = self.accmd_send("CREATE_OPERATOR_REQ",
                               param_words= [ 0x4001],
                               response_name="CREATE_OPERATOR_RESP")
        download_op.id = resp.params[0]
        iprint("Download self test operator 0x%x created" % (download_op.id))
        return download_op

    def destroy_download_self_test_op(self, download_op):
        resp = self.accmd_send("DESTROY_OPERATORS_REQ",
                               param_words= [1, download_op.id],
                               response_name="DESTROY_OPERATORS_RESP")
        iprint("Download self test operator 0x%x destroyed %s" % (download_op.id, resp.status))

    def create_aptx_operator(self):
        aptx_op = NameSpace()
        resp = self.accmd_send("CREATE_OPERATOR_REQ",
                               param_words= [ 0x19],
                               response_name="CREATE_OPERATOR_RESP")
        aptx_op.id = resp.params[0]
        aptx_op.src_ep_L  = self.source_from_operator_terminal(aptx_op.id, 0)
        aptx_op.src_ep_R  = self.source_from_operator_terminal(aptx_op.id, 1)
        aptx_op.sink_ep   = self.sink_from_operator_terminal(aptx_op.id, 0)
        iprint("Aptx operator 0x%x created, src_ep_L=%d, src_ep_R=%d, sink_ep=%d " % (aptx_op.id,aptx_op.src_ep_L,aptx_op.src_ep_R,aptx_op.sink_ep))
        return aptx_op

    def destroy_copy_operator(self, copy_op):
        stop_resp = self.accmd_send("STOP_OPERATORS_REQ",
                                    param_words=[1, copy_op.id],
                                    response_name="STOP_OPERATORS_RESP")
        iprint("Stop resp %s" % stop_resp.status)
        resp = self.accmd_send("DESTROY_OPERATORS_REQ",
                               param_words= [1, copy_op.id],
                               response_name="DESTROY_OPERATORS_RESP")
        iprint("Copy operator 0x%x destroyed %s" % (copy_op.id, resp.status))

    def destroy_aptx_operator(self, aptx_op):
        stop_resp = self.accmd_send("STOP_OPERATORS_REQ",
                                    param_words=[1, aptx_op.id],
                                    response_name="STOP_OPERATORS_RESP")
        iprint("Stop resp %s" % stop_resp.status)
        resp = self.accmd_send("DESTROY_OPERATORS_REQ",
                               param_words= [1, aptx_op.id],
                               response_name="DESTROY_OPERATORS_RESP")
        iprint("Copy operator 0x%x destroyed %s" % (aptx_op.id, resp.status))

    def _connect_endpoints(self, sink_ep, src_ep, copy_op):
        MSG_INPUT_DATA_TYPE = 10
        MSG_OUTPUT_DATA_TYPE = 11
        DATA_16BE = 0
        LINEAR_16LE = 1

        resp = self.accmd_send("STREAM_CONNECT_REQ",
                   param_words= [copy_op.src_ep, src_ep],
                   response_name = "STREAM_CONNECT_RESP")
        src_transform = resp.params[0]
        iprint("Source transform = 0x%x" % src_transform)

        resp = self.accmd_send("STREAM_CONNECT_REQ",
                   param_words= [sink_ep, copy_op.sink_ep],
                   response_name = "STREAM_CONNECT_RESP")
        sink_transform = resp.params[0]
        iprint("Sink transform 0x%x" % sink_transform)

        # Set copy operator source and sink to 16-bit audio
        resp = self.accmd_send("OPERATOR_MESSAGE_REQ",
                   param_words=[copy_op.id, MSG_INPUT_DATA_TYPE, DATA_16BE],
                   response_name = "OPERATOR_MESSAGE_RESP")
        iprint("OP message resp %s (%s)" % (resp.params, resp.status))
        resp = self.accmd_send("OPERATOR_MESSAGE_REQ",
                   param_words=[copy_op.id, MSG_OUTPUT_DATA_TYPE, DATA_16BE],
                   response_name = "OPERATOR_MESSAGE_RESP")
        iprint("OP message resp %s (%s)" % (resp.params, resp.status))

        start_resp = self.accmd_send("START_OPERATORS_REQ",
                                    param_words=[1, copy_op.id],
                                    response_name="START_OPERATORS_RESP")
        iprint("Start resp %s" % start_resp.status)

    def _get_handle_from_endpoint(self, endpoint_id):
        handle_p = self._core.fw.env.gv["tr_audio_data"].members["data_links"]
        while handle_p.value:
            handle = handle_p.deref
            if handle.members["audio_endpoint_id"].value == endpoint_id:
                return handle
            handle_p = handle.members["p_next"]

    def _connect_aptx_endpoints(self, sink_ep, src_ep_L, src_ep_R, aptx_op):
        MSG_INPUT_DATA_TYPE = 10
        MSG_OUTPUT_DATA_TYPE = 11
        DATA_16BE = 0
        LINEAR_16LE = 1

        iprint("connecting 0x%x to 0x%x" % (aptx_op.src_ep_L,src_ep_L))
        resp = self.accmd_send("STREAM_CONNECT_REQ",
                   param_words= [aptx_op.src_ep_L, src_ep_L],
                   response_name = "STREAM_CONNECT_RESP")
        src_transform = resp.params[0]
        iprint("Source transform = 0x%x" % src_transform)
        #####raw_input()

        iprint("connecting 0x%x to 0x%x" % (aptx_op.src_ep_R,src_ep_R))
        resp = self.accmd_send("STREAM_CONNECT_REQ",
                   param_words= [aptx_op.src_ep_R, src_ep_R],
                   response_name = "STREAM_CONNECT_RESP")
        src_transform = resp.params[0]
        iprint("Source transform = 0x%x" % src_transform)
        #####raw_input()

        iprint("connecting 0x%x to 0x%x" % (aptx_op.sink_ep,sink_ep))
        resp = self.accmd_send("STREAM_CONNECT_REQ",
                   param_words= [sink_ep, aptx_op.sink_ep],
                   response_name = "STREAM_CONNECT_RESP")
        sink_transform = resp.params[0]
        iprint("Sink transform 0x%x" % sink_transform)
        #####raw_input()

        # Set aptx operator source and sink to 16-bit audio
#        resp = self.accmd_send("OPERATOR_MESSAGE_REQ",
#                   param_words=[aptx_op.id, MSG_INPUT_DATA_TYPE, DATA_16BE],
#                   response_name = "OPERATOR_MESSAGE_RESP")
#        iprint("OP message resp %s (%s)" % (resp.params, resp.status))
#        resp = self.accmd_send("OPERATOR_MESSAGE_REQ",
#                   param_words=[aptx_op.id, MSG_OUTPUT_DATA_TYPE, DATA_16BE],
#                   response_name = "OPERATOR_MESSAGE_RESP")
#        iprint("OP message resp %s (%s)" % (resp.params, resp.status))

        iprint("Sending START_OPERATORS_REQ message....")
        start_resp = self.accmd_send("START_OPERATORS_REQ",
                                    param_words=[1, aptx_op.id],
                                    response_name="START_OPERATORS_RESP")
        iprint("Start resp %s" % start_resp.status)

    def _get_handle_from_endpoint(self, endpoint_id):
        handle_p = self._core.fw.env.gv["tr_audio_data"].members["data_links"]
        while handle_p.value:
            handle = handle_p.deref
            if handle.members["audio_endpoint_id"].value == endpoint_id:
                return handle
            handle_p = handle.members["p_next"]


    def tcpserver(self, port=9901, timeout=0.2):
        '''
        Run a TCP server that can be connected to by an omnicli so commands
        and responses are passed through the apps audio accmd transport.

        Note that this will accept only one incoming connection. If you
        disconnect your Omnicli, you'll have to stop this tcpserver() and
        start another one.

        Run omnicli with the following commands:
        > omnicli
        OmniCli v0.0.0.2: Built Dec  3 2009 17:25:54
        Copyright (c) 2014 - 2016 Qualcomm Technologies International, Ltd.
        11:36:03.745 I  loopback - Loopback
        11:36:03.745 I  tcpclient - TCP Client
        11:36:03.745 I  tcpserver - TCP Server
        11:36:03.745 I  ucaps - UCAPS Logger
        11:36:03.745 I 4 connections available
        11:36:03.745 I  btdata - Bluetooth data transfer commands
        11:36:03.745 I  example - Example OmniCli extension
        11:36:03.745 I 2 extensions available
        % load c:\perforce\app_ss\main\common\interface\accmd_saps.xml
        11:36:42.372 E Type 'nulltermstring' with basictype of asciistring must have size of 16.
        11:36:42.372 I Successfully loaded 1 file.
        11:36:42.372 I The following SAPs are available:
        11:36:42.372 I  audio_accmd
        11:36:42.372 I 1 available SAP
        11:36:42.372 I Use 'sapconnect' command to connect to a device
        11:36:42.372 I Type 'help commands' to get a list of added commands.
        % sapconnect audio_accmd tcpclient localhost:9901
        09:48:14.902 I connecting to 'tcpclient'
        09:48:14.902 I connected
        % get_firmware_version_req 43
        09:48:17.149 > get_firmware_version_req seq_no:0x002b
        % 09:48:17.195 < get_firmware_version_resp seq_no:0x002b ok version:0xffff
        % get_firmware_id_string_req 1
        09:48:27.679 > get_firmware_id_string_req seq_no:0x0001
        % 09:48:27.726 < get_firmware_id_string_resp seq_no:0x0001 ok id_stri...
        % get_firmware_id_string_req 4
        09:48:30.644 > get_firmware_id_string_req seq_no:0x0004
        % 09:48:30.691 < get_firmware_id_string_resp seq_no:0x0004 ok id_stri...
        '''
        self.start_tcpserver(port=port, timeout=timeout)
        poll_loop()

    def start_tcpserver(self, port=9901, timeout=0.2):
        if not self.is_started():
            iprint("Starting audio command service")
            self.start(timeout)
            self.tcp_owned_accmd = True
        else:
            self.tcp_owned_accmd = False
        self.omnicli_rx_data = []
        iprint("Setting up ACCMD tcp server on port %d" % port)
        self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # On Unix-ish systems, you need SO_REUSEADDR to give sane socket
        # semantics (to avoid failure to bind to the same port twice in
        # quick succession due to the TIME_WAIT state; see
        # _TCP/IP Illustrated Volume 1_, Chapter 18 "TCP Connection
        # Establishment and Termination", 18.6 "TCP State Transition
        # Diagram", p243).
        #
        # Windows has these sane semantics by default; but has reused the
        # name SO_REUSEADDR to do something completely different and
        # ridiculous that you never want.
        # <https://msdn.microsoft.com/en-us/library/windows/desktop/ms740621%28v=vs.85%29.aspx>
        #
        # Windows (only) has another socket option, SO_EXCLUSIVEADDRUSE, to
        # try to patch around the worst of its SO_REUSEADDR semantics. This
        # seems like a good thing to test for to determine whether we are
        # on a platform with a given combination of socket semantics.
        #
        # (That is: we expect this setsockopt to be executed on Unix and not
        # on Windows.)
        if not hasattr(socket, 'SO_EXCLUSIVEADDRUSE'):
            self.s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.s.bind(("localhost", port))
        self.s.settimeout(0.1)
        self.s.listen(1)
        add_poll_function("audio tcp connect", self._poll_for_tcp_connection)

    def _poll_for_tcp_connection(self):
        try:
            self.conn, self.addr = self.s.accept()
            if self.conn:
                self.conn.settimeout(0.1)
        except socket.timeout:
            return
        iprint('ACCMD TCP connection received from:', self.addr)
        remove_poll_function("audio tcp connect")
        add_poll_function("audio tcp data", self._poll_for_tcp_data)

    def _poll_for_tcp_data(self):
        try:
            data = self.conn.recv(1024)
        except socket.timeout:
            pass
        else:
            if len(data) == 0:
                # Remote end closed connection
                # This tcpserver is useless now. Discard?
                iprint('ACCMD TCP client closed connection')
                # Allow the poll loop to exit if appropriate
                remove_poll_function("audio tcp data")
                if self.tcp_owned_accmd:
                    self.stop()
                return
            # list(bytearray(data)) produces a list of integers equal to the
            # bytes in data, if data is a bytes object.
            # Since bytes and str are the same thing in Python 2.7, this gives 
            # us what we want. (In Py3 we could just do list(data), but that
            # doesn't work in Py2).
            self.forward_omnicli_data(list(bytearray(data)))

        accmd_response = self.get_response(timeout=0)
        if accmd_response:
            self.conn.sendall(self.format_response_for_omnicli(accmd_response))

    def stop_tcpserver(self):
        try:
            remove_poll_function("audio tcp connect")
        except KeyError:
            pass
        try:
            remove_poll_function("audio tcp data")
        except KeyError:
            pass
        self.conn.close()
        iprint("Connection closed")



    def forward_omnicli_data(self, data_byte_list):
        if self.verbose_debug:
            iprint("received data:", [hex(a) for a in data_byte_list])
        self.omnicli_rx_data += data_byte_list
        if len(self.omnicli_rx_data) >= self._tcp_header_len:
            tcp_header = bytes_to_dwords(
                               self.omnicli_rx_data[0:self._tcp_header_len])
            if tcp_header[0] != self.TCP_MAGIC_SIGNAL_START:
                raise self.TestError("Unexpected TCP header magic %x" % tcp_header[0])
            tcp_payload_len = tcp_header[1]
            if len(self.omnicli_rx_data) >= tcp_payload_len + self._tcp_header_len:
                accmd = self.omnicli_rx_data[self._tcp_header_len:
                                             self._tcp_header_len + tcp_payload_len]
                iprint("Forward %s to apps" % self.Accmd(self, accmd))
                self.send_command(accmd)

                self.omnicli_rx_data = self.omnicli_rx_data[
                                        self._tcp_header_len + tcp_payload_len:]

    def format_response_for_omnicli(self, accmd_bytes):
        if self.verbose_debug:
            iprint("Returning %s to omnicli" % self.Accmd(self, accmd_bytes))
        if type(accmd_bytes) == bytearray:
            # ptap test tunnel 
            barray = bytearray(dwords_to_bytes([self.TCP_MAGIC_SIGNAL_START,
                                      len(accmd_bytes)])) + accmd_bytes
        else:
            byte_list = dwords_to_bytes([self.TCP_MAGIC_SIGNAL_START,
                                      len(accmd_bytes)]) + accmd_bytes
            barray = bytearray(byte_list)
        # We need a bytes object to be returned because this is sent to a socket
        return bytes(barray)

    class Accmd():
        def __init__(self, parent, accmd_bytes):
            self._parent = parent
            self._accmd_header_len = 6
            self.len = len(accmd_bytes)
            accmd_header = bytes_to_words(accmd_bytes[0:self._accmd_header_len])
            self.id = accmd_header[0]
            self.param_len = accmd_header[1]
            self.sequence_num = accmd_header[2]
            self.params = bytes_to_words(accmd_bytes[self._accmd_header_len:
                                                     self._accmd_header_len + self.param_len])
            try:
                self.name = self._parent.accmd_names[self.id]
            except KeyError:
                self.name = "Unknown ACCMD ID 0x%x" % self.id
            self.status = None
            if self.name.endswith("_RESP"):
                try:
                    self.status = self._parent.accmd_status[self.params[0]]
                    self.params = self.params[1:]
                except (IndexError, KeyError):
                    pass

        def __str__(self):
            if self.status:
                return "%s seq %d %s %s" % (self.name, self.sequence_num,
                                            self.status,
                                            ["0x%x" %x for x in self.params])
            else:
                return "%s seq %d %s" % (self.name, self.sequence_num,
                                            ["0x%x" %x for x in self.params])


class AudioDataTestTunnel():
    def __init__(self, core, test_tunnel):
        self._core = core
        self.test_tunnel = test_tunnel
        self.handlers = {}
        self.test_tunnel.register_handler("audio_data", self.pdu_handler,
                                                            byte_based=True)
        self.hip = test_tunnel.hip
        self.pkt_ids = self.hip.get_enum_dict("TEST_TUNNEL_AUDIO_PKT_TYPE")
        self.pkt_names = create_reverse_lookup(self.pkt_ids)
        self._pending_responses = []
        self._endpoint_handlers = {}
        self.endpoint_files = {}
        self.flow_control_debug = False
        self._started = False
        self.pkt_delta = None

    def __del__(self):
        self.stop()

    def stop(self):
        if self._started:
            self.test_tunnel.disconnect("audio_data")
            self._started = False

    def send(self, cmd, params, payload_bytes=[]):
        if not self._started:
            self.test_tunnel.connect("audio_data")
            self._started = True
        self.test_tunnel.send_bytes("audio_data",
                words_to_bytes([self.pkt_ids[cmd]] + params) + payload_bytes)

    def start_sink_from_file(self, endpoint_id, file_name, pkt_size=200, meta=False, pkt_delta=None):
        file_object = { "file_name" : file_name,
                        "fd": open(file_name, "rb"),
                        "total_bytes" : os.stat(file_name).st_size,
                        "pkt_size" : pkt_size,
                        "bytes_sent" : 0,
                        "bytes_sent_not_consumed" : 0,
                        "pkt_delta" : pkt_delta,
                        "next_pkt_time" : None if pkt_delta == None else 200000 + int(self._core.fields.TIMER_TIME),
                        "pkts_sent_not_consumed" : 0,
                        "pkts_sent" : 0,
                        "space_avail" : 0,
                        "MetaLen" : meta }
        self.endpoint_files[endpoint_id] = file_object
        self.register_handler(endpoint_id, self._send_file_flow_control_handler)
        self.send("Flow_Control_Req", [ endpoint_id ])

    def _send_file_flow_control_handler(self, endpoint_id, consumed, avail,
                                        pkts_consumed, available_pkts):
        try:
            f = self.endpoint_files[endpoint_id]
        except KeyError:
            return False
        if self.flow_control_debug:
            iprint("Endpoint 0x%x fc of %d consumed, %d avail, %d in transit" % (
                    endpoint_id, consumed, avail, f["bytes_sent_not_consumed"]))
        f["bytes_sent_not_consumed"] -= consumed
        f["pkts_sent_not_consumed"] -= pkts_consumed
        f["space_avail"] = avail - f["bytes_sent_not_consumed"]
        f["pkt_space_avail"] = available_pkts - f["pkts_sent_not_consumed"]
        file_bytes_left = f["total_bytes"] - f["bytes_sent"]
        if file_bytes_left == 0 and f["bytes_sent_not_consumed"] == 0:
            f["fd"].close()
            iprint("Ep 0x%x file send of %d bytes complete" % (
                                              endpoint_id, f["total_bytes"]))
            self.endpoint_files.pop(endpoint_id)
            return True
        space_for_pkts = f["space_avail"] // f["pkt_size"]
        file_pkts_left = (file_bytes_left + f["pkt_size"] - 1) // f["pkt_size"]
        pkts_to_send = min(space_for_pkts - 1, file_pkts_left, f["pkt_space_avail"])
        if pkts_to_send > 0:
            if self.flow_control_debug:
                iprint("Sending %d packets (%d bytes) for avail %d/%d" %(
                                                  pkts_to_send,
                                                  pkts_to_send * f["pkt_size"],
                                                  f["pkt_space_avail"],
                                                  f["space_avail"]))
            for dummy in range(pkts_to_send):
                if f["MetaLen"] >= 2:
                    header_len = f["MetaLen"]-2
                    meta_data = self.make_test_meta_data(header_len, f["pkts_sent"])
                    if f["next_pkt_time"] != None:
                        pkt_type = "TimedDataFrame"
                        if self.flow_control_debug:
                            iprint("Send pkt %d (%d)" %(f["pkts_sent"], f["next_pkt_time"]))
                        params = dwords_to_words([f["next_pkt_time"]]) + [endpoint_id, header_len<<8 | 1]
                        f["next_pkt_time"] += f["pkt_delta"]
                    else:
                        pkt_type = "DataFrame"
                        params = [endpoint_id, header_len<<8 | 1]
                else:
                    # retimer support available for "Data" frames ?
                    pkt_type = "Data"
                    params = [ endpoint_id ]
                    meta_data = []
                data = f["fd"].read(f["pkt_size"])
                try:
                    self.send(pkt_type, params, meta_data + [ord(a) for a in data])
                except CurBuffer.BufferFull:
                    iprint("EP 0x%x send delayed by full buffer" % endpoint_id)
                    break
                f["bytes_sent_not_consumed"] += len(data)
                f["pkts_sent_not_consumed"] += 1
                f["bytes_sent"] += len(data)
                f["pkts_sent"] += 1
        return True 

    def make_test_meta_data(self, meta_len, index):
        '''
        Create the test meta data for attaching to each packet. This is the
        8 or 16-bit representation of the index parameter (that can be used 
        as a packet count) followed by a fill value. Older audio firmware
        didn't have the internal plumbing to loop back metadata properly,
        so it just made some test metadata up for the source service; this
        matches its test pattern, so was once needed for the test to pass.
        '''
        FILL_VALUE = 0
        meta_data = []
        if meta_len:
            meta_len -= 1
            meta_data += [index & 0xff]
        if meta_len:
            meta_len -= 1
            meta_data += [(index >> 8) & 0xff]
        if meta_len:
            meta_data += [FILL_VALUE] * meta_len
            meta_len = 0
        return meta_data
             
    def wait_for_file_complete(self, endpoint_ids):
        self.polled_endpoint_ids = endpoint_ids
        add_poll_function("audio_files", self.waif_for_file_complete_poll_call)
        try:
            poll_loop(True)
        except KeyboardInterrupt:
            if not self.wait_for_file_complete_poll(self.polled_endpoint_ids):
                raise
        remove_poll_function("audio_files")
        
    def waif_for_file_complete_poll_call(self):
        ''' To be called from poll_loop() to wait for file transfer 
        completion '''
        if self.wait_for_file_complete_poll(self.polled_endpoint_ids):
            raise KeyboardInterrupt
        
    def wait_for_file_complete_poll(self, endpoint_ids):
        if not isinstance(endpoint_ids, list):
            endpoint_ids = [ endpoint_ids ]
        if True in [ep in self.endpoint_files for ep in endpoint_ids]:
            self.test_tunnel.poll_for_rx()
        else:
            return True
        

    def start_file_from_source(self, endpoint_id, file_name, max_bytes=0):
        file_object = { "file_name" : file_name,
                        "fd": open(file_name, "wb"),
                        "bytes" : 0,
                        "pkts" : 0,
                        "headers" : [],
                        "max_bytes" : max_bytes
                        }
        self.endpoint_files[endpoint_id] = file_object
        self.register_handler(endpoint_id, self._receive_file_data_handler)

    def _receive_file_data_handler(self, endpoint_id, data, header):
        f = self.endpoint_files[endpoint_id]
        bytes = len(data)
        f["fd"].write(array.array("B", data).tostring())
        if header:
            f["headers"].append(list(header))
        f["bytes"] += bytes
        f["pkts"] += 1
        if f["max_bytes"] and f["bytes"] >= f["max_bytes"]:
            f["fd"].close()
            iprint("Ep 0x%x file receive of %d bytes complete" % (
                                              endpoint_id, f["bytes"]))
            if f["headers"]:
                expected_headers = [
                            self.make_test_meta_data(len(f["headers"][0]), a)
                                        for a in range(len(f["headers"])) ]
                if f["headers"] != expected_headers:
                    iprint("Headers not correctly received: %s != %s" % (f["headers"], expected_headers))
                else:
                    iprint("Headers received OK")
            self.endpoint_files.pop(endpoint_id)
            return True
        return True

    def pdu_handler(self, pdu):
        consumed = False
        audio_data_pdu = pdu["payload"]
        try:
            pdu["id"] = id = self.pkt_names[bytes_to_words(audio_data_pdu[0:2])[0]]
        except KeyError:
            iprint("Undecodable pdu %s" % pdu)
            return pdu
        if id == "Data" or id=="DataFrame":
            pdu["endpoint_id"] = endpoint = bytes_to_words(audio_data_pdu[2:4])[0]
            if id=="DataFrame":
                pdu["pkt_boundary"] = audio_data_pdu[4]
                hdr_len = audio_data_pdu[5]
                pdu["header"] = header = audio_data_pdu[6:6+hdr_len]
                pdu["payload"] = data = audio_data_pdu[6+hdr_len:]
            else:
                pdu["payload"] = data = audio_data_pdu[4:]
                header = None
            if endpoint in self._endpoint_handlers:
                consumed = self._endpoint_handlers[endpoint](endpoint, data, header)
            if not consumed:
                self._pending_responses.append({"id":id,
                                            "payload":pdu["payload"],
                                            "header":header,
                                            "endpoint_id":pdu["endpoint_id"]})
        elif id == "Create_Cfm" or id == "Destroy_Cfm":
            params = bytes_to_words(audio_data_pdu[2:])
            resp = { "id" : id,
                    "response" : self.test_tunnel.rsp_names[params[0]],
                    "endpoint_id" : params[1] }
            if id == "Create_Cfm":
                resp["available_bytes"] = params[2]
            pdu.pop("payload")
            pdu.update(resp)
            self._pending_responses.append(resp)

        elif id == "Flow_Control_Ind":
            params = bytes_to_words(audio_data_pdu[2:])
            pdu["endpoint_id"] = endpoint = params[0]
            pdu["bytes_consumed"] = consumed = params[1]
            pdu["available_bytes"] = avail = params[2]
            pdu["pkts_consumed"] = pkts_consumed = params[3]
            pdu["available_pkts"] = available_pkts = params[4]
            pdu.pop("payload")
            if endpoint in self._endpoint_handlers:
                consumed = self._endpoint_handlers[endpoint](endpoint,
                                     int(consumed), int(avail),
                                     int(pkts_consumed), int(available_pkts))
            if not consumed:
                self._pending_responses.append({"id":id,
                                            "endpoint_id" : endpoint,
                                            "bytes_consumed" : consumed,
                                            "available_bytes" : avail,
                                            "pkts_consumed" : pkts_consumed,
                                            "available_pkts" : available_pkts })
        return pdu if not consumed else None

    def get_response(self):
        if self._pending_responses:
            return self._pending_responses.pop(0)
        return None

    def wait_for_response(self, timeout=0.2):
        if timeout:
            start_time = timeout_clock()
        while True:
            self.test_tunnel.poll_for_rx()
            resp = self.get_response()
            if resp:
                return resp
            if timeout:
                if timeout_clock() - start_time > timeout:
                    raise self.test_tunnel.TimeoutError
            else:
                return None

    def register_handler(self, endpoint_id, handler):
        self._endpoint_handlers[endpoint_id] = handler

    def test_timed(self, endpoint_id, delta_times_ms=[50, 100, 150, 200], header_len=0):
        results = self.send_timed_packets(endpoint_id, 
                                          delta_times_ms, 
                                          header_len=header_len)
        test_pass = True
        for requested, actual, error in results:
            iprint("Expected %.1f, Actual %.1f, Error %.3f ms" % (
                                                     requested, actual, error))
            if not -1 < error < 1:
                test_pass = False
        return test_pass

    def send_timed_packets(self, endpoint_id, delta_times_ms, header_len=0): 
        self._core.fw.debug_log.log_level("transport_audio", 4)
        self._core.subsystem.chip.trb_log.start()
        self._core.subsystem.chip.trb_log.show(TimedLog())
        self._core.subsystem.chip.trb_log.clear()

        current_time = int(self._core.fields.TIMER_TIME)
        presentation_times = [current_time + (delta_time_ms * 1000) 
                                  for delta_time_ms in delta_times_ms]
        for presentation_time in presentation_times:
            self.send_timed(endpoint_id, presentation_time, header_len=header_len)
            
        rx_pkts = []
        for presentation_time in presentation_times:
            rx_pkts.append(self.wait_for_response(0.5))

        fwlog = TimedLog()
        self._core.subsystem.chip.trb_log.show(fwlog)
        self._core.subsystem.chip.trb_log.stop()
        audio_copy_msgs = fwlog.filter("TRANS AUDIO").filter("copied")
        log_times = [audio_copy_msgs.timestamp_us(entry)
                                    for entry in audio_copy_msgs.log]
        if len(log_times) > len(delta_times_ms):
            # Take the latest messages from the log
            log_times = log_times[-len(delta_times_ms):]

        act_delta_times_ms = [(a - log_times[0]) / 1000 for a in log_times]
        req_delta_times_ms = [ a - delta_times_ms[0] for a in delta_times_ms]
        return [(request, actual, actual-request)             
                for actual,request in zip(act_delta_times_ms, 
                                          req_delta_times_ms)]

    def send_timed(self, endpoint_id, presentation_time, header_len=0, data_len=100):
        params = dwords_to_words([presentation_time]) + [endpoint_id, header_len<<8 | 1]
        meta_data = self.make_test_meta_data(header_len, 0xab)
        data = range(data_len)
        self.send("TimedDataFrame", params, meta_data + data)
                
if __name__ == "__main__":
    try:
        aud = TransAudio(appcmd)
    except NameError:
        aud = TransAudio(apps.fw.appcmd)

